package Threads;

public class DaemonDemo extends Thread{
	public void run() {
		System.out.println("In run method");
	if(DaemonDemo.currentThread().isDaemon())
	{
		System.out.println("I am in Daemon");
	}
	else {
		System.out.println("I am not in Daemon");
	}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Main Thread");
DaemonDemo td=new DaemonDemo();
td.setDaemon(true);
td.start();

	}

}
