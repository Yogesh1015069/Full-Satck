package Threads;

public class Singlethread extends Thread {
//single task using multiple thread
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String [] args)
	{
		Singlethread t=new Singlethread();
		t.start();
		/*Singlethread td1=new Singlethread();
		td1.start();*/
	}
}
