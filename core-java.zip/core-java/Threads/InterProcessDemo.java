package Threads;
class Revenue extends Thread
{
	int total=0;
	public void run() {
		synchronized(this)
		{
		for(int i=0;i<=5;i++)
		{
			total=total+400;
		}
		this.notify();//lock again given to main
		}
	}
}
public class InterProcessDemo {
public static void main(String []args) throws Exception
{
	Revenue r=new Revenue();
	r.start();//Thread
	//System.out.println("Total Amount"+r.total);
	synchronized(r)
	{
		r.wait();
		System.out.println("Total Amount"+r.total);
	}
}
}
