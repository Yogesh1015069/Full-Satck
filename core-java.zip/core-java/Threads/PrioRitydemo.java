package Threads;

public class PrioRitydemo extends Thread{

	public void run()
	{
		System.out.println("In run Method");
		System.out.println(Thread.currentThread().getPriority());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println(Thread.currentThread().getPriority());//5
Thread.currentThread().setPriority(MIN_PRIORITY);
System.out.println(Thread.currentThread().getPriority());
PrioRitydemo p=new PrioRitydemo();
p.start();
	}

}
