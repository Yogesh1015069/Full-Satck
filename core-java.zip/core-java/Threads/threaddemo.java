package Threads;
public class threaddemo implements Runnable{
	public void run()
	{
		System.out.println("Thread Started");
		
	}
/*public class threaddemo extends Thread {
public void run()
{
	System.out.println("Thread Started");
	
}*/
	public static void main(String[] args) {
		// TODO Auto-generated method 
		Thread t=new Thread(new threaddemo());
		t.start();
		
		/*threaddemo t=new threaddemo();
		t.start();
	*/
	}

}
