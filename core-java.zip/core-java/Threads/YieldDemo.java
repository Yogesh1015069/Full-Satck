package Threads;

public class YieldDemo extends Thread{
	public void run() {
		for(int i=0;i<5;i++)
		{
			Thread.yield();
			System.out.println("Thread started"+Thread.currentThread().getName());
		}
		System.out.println("thread endend"+Thread.currentThread().getName());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		YieldDemo yd=new YieldDemo();
		yd.start();
		for(int i=0;i<5;i++)
		{
			
			System.out.println("Thread started "+Thread.currentThread().getName());
		}
		System.out.println("thread endend "+Thread.currentThread().getName());
	
	}

}
