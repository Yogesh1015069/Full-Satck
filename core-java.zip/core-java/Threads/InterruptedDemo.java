package Threads;

public class InterruptedDemo extends Thread {
	public void run()
	{
		//System.out.println(Thread.interrupted());
		try{
			for(int i=0;i<5;i++)
	{
		System.out.println(i);
		Thread.sleep(2000);
		//System.out.println(Thread.interrupted());
	}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
InterruptedDemo i=new InterruptedDemo();
i.start();//Thread-0
i.interrupt();//true
	}

}
