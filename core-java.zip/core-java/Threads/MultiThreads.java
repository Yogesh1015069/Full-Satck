package Threads;
//
class Mythread1 extends Thread
{
	public void run()
	{
		System.out.println("i am thread1");
	}
}
class Mythread2 extends Thread
{
	public void run()
	{
		System.out.println("i am thread2");
	}
}
class Mythread3 extends Thread
{
	public void run()
	{
		System.out.println("i am thread3");
	}
}
public class MultiThreads {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Mythread1 t1=new Mythread1();
		t1.start();
		Mythread2 t2=new Mythread2();
		t2.start();
		Mythread3 t3=new Mythread3();
		t3.start();
	}

}
