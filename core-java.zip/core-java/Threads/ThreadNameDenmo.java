package Threads;

public class ThreadNameDenmo extends Thread{
public void run()
{
	Thread.currentThread().setName("Run");
	System.out.println("Run:"+Thread.currentThread().getName());
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println(Thread.currentThread().getName());
	Thread.currentThread().setName("Yash");
	ThreadNameDenmo t1=new ThreadNameDenmo();
	System.out.println(t1.isAlive());//false
	t1.setName("T1 Thread");
	t1.start();
	System.out.println(t1.isAlive());//true
	System.out.println(Thread.currentThread().isAlive());//true
	ThreadNameDenmo t2=new ThreadNameDenmo();
	t2.setName("T2 Thread");
	t2.start();
	//System.out.println(Thread.currentThread().getName());
	}

}
