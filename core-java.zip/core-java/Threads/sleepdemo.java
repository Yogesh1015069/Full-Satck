package Threads;

public class sleepdemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
		for(int i=0;i<5;i++)
{
	Thread.sleep(6000);
	System.out.println(i);
}}
catch(Exception e)
{
	System.out.println(e);
}
	}

}
