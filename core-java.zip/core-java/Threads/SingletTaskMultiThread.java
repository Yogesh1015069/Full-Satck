package Threads;

public class SingletTaskMultiThread extends Thread{
	public void run()
	{
		System.out.println("Thread Started");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingletTaskMultiThread t=new SingletTaskMultiThread();
		t.start();
		SingletTaskMultiThread td1=new SingletTaskMultiThread();
		td1.start();
	}
	}

}
