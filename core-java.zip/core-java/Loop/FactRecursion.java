package Loop;

import java.util.Scanner;

public class FactRecursion {
	public static int factorial(int n)
	{
		
	if(n==0)
	{
		return 1;
	}
	
	else 
		return n*factorial(n-1);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n1,n2;
		System.out.println("enter the 1st Number");
		n1=sc.nextInt();
		System.out.print(factorial(n1));
	}

}
