package Loop;

import java.util.Scanner;

public class Prime {
public static void prime(int n)
{int m=n/2;
	if(n==0||n==1)
	{
		System.out.println("number is prime");
	}
	else 
	{
		for(int i=2;i<=m;i++)
		{
			if(n%i==0)
			{
				System.out.println(n+" is not prime number");
				break;
			}
			else {
				System.out.println(n+" is  prime number");
			}
		}
	}
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n1;
		System.out.println("enter the Number");
		n1=sc.nextInt();
		prime(n1);
	}

}
