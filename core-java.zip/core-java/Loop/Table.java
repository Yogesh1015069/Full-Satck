package Loop;

import java.util.Scanner;

public class Table {
	public static void table(int n) {
		for(int i=1;i<=10;i++)
			
		{
			System.out.println(n+" X "+i+" = "+n*i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n1,n2;
		System.out.println("enter the 1st Number");
		n1=sc.nextInt();
		table(n1);
		
	}

}
