package Loop;

import java.util.Scanner;

public class Reverse {
public static int reverse(int n)
{int r=0;
	while(n>0)
	{
		int re=n%10;
		r=(r*10)+re;
		n=n/10;
	}
	return r;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n1,n2;
		System.out.println("enter the 1st Number");
		n1=sc.nextInt();
		System.out.print(reverse(n1));
	}

}
