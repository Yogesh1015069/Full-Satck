package Fundamentles;

import java.util.Scanner;

public class LeapYear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int y;
		System.out.println("enter the year to check");
		y=sc.nextInt();
		 if (((y % 4 == 0) && (y % 100!= 0)) || (y%400 == 0))
	         System.out.println("Specified year "+y+" is a leap year");
	      else
	         System.out.println("Specified year "+y+" is not a leap year");
	}

}
