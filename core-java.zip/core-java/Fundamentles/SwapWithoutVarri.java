package Fundamentles;

import java.util.Scanner;

public class SwapWithoutVarri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc= new Scanner(System.in);
		int n1,n2;
		System.out.println("enter the 1st Number");
		n1=sc.nextInt();
		System.out.println("enter the 2nd number");
		n2=sc.nextInt();
		System.out.println("before Swaping n1 = "+n1+" n2 ="+n2);
		n1=n1+n2;
		n2=n1-n2;
		n1=n1-n2;
		System.out.println("After swaping n1 = "+n1+" n2 ="+n2);
	}

}
