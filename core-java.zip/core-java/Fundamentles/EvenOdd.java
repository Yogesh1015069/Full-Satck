package Fundamentles;
import java.util.Scanner;
public class EvenOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n1=20;
		System.out.println("enter the Number");
	
	if(n1%2==0)
	{
		System.out.println(n1 +" is even");
	}
	else
	{
		System.out.println(n1+" is odd");
	}
	}

}
