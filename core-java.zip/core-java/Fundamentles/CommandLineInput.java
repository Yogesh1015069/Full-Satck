package Fundamentles;

public class CommandLineInput {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=Integer.parseInt(args[0]);
		double b=Double.parseDouble(args[1]);
		float f=Float.parseFloat(args[2]);
		System.out.println(a+" "+b+" "+f);
	}

}
