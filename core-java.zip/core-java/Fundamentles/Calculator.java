package Fundamentles;

import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		int n1,n2;
		System.out.println("enter the 1st Number");
		n1=sc.nextInt();
		System.out.println("enter the 2nd number");
		n2=sc.nextInt();
		
		System.out.println("Select the operation below ");
		System.out.println("+ for addition");
		System.out.println("- for subtraction");
		System.out.println("* for multiplication");
		System.out.println("/ for division");
		char c=sc.next().charAt(0);
		int result;
switch(c)
{
case '+':
	result=n1+n2;
	System.out.println("sum of "+n1+"+"+n2+" is "+result);
	break;
case '-':
	result=n1-n2;
	System.out.println("sum of "+n1+"-"+n2+" is "+result);
	break;
case '*':
	result=n1+n2;
	System.out.println("sum of "+n1+"*"+n2+" is "+result);
	break;
	
case '/':
	result=n1+n2;
	System.out.println("sum of "+n1+"/"+n2+" is "+result);
	break;
	
default :
	System.out.println("Invalid Input");
	break;

}
	}

}
