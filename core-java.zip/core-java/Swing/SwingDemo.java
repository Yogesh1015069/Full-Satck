package Swing;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPasswordField;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SwingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
JFrame f=new JFrame("This is my Yard");

JTextField t1=new JTextField("Enter Your name");
t1.setBounds(50,100,200,30);
JTextArea a=new JTextArea("enter thr name");
a.setBounds(50,100,40,30);
JPasswordField pass=new JPasswordField("enter the password");
pass.setBounds(50,100,120,30);
JButton button=new JButton("submit");
button.setBounds(50,100,80,30);
JCheckBox c=new JCheckBox("Male or female");
c.setBounds(50,100,40,20);
f.add(t1);
f.add(pass);
f.add(a);
f.add(button);
f.add(c);
f.setSize(1080,720);
f.setLayout(null);
f.setVisible(true);

	}

}
