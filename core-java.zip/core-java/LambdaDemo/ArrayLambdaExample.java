package LambdaDemo;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayLambdaExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList <Integer> a=new ArrayList<Integer>();
		a.add(50);
		a.add(45);
		a.add(98);
		Iterator i=a.iterator();
		while(i.hasNext())
		{
			System.out.print(i.next());
			System.out.print(",");
		}
		System.out.println();
		System.out.println("Now Using the lambda method or expression");
		a.forEach((n)->{System.out.println(n);});

	}

}
