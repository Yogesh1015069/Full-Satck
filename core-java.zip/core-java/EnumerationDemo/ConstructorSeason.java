package EnumerationDemo;
enum season
{
	AUTUMN,SPRING,WINTER,SUMMER;
String Seasons;	
season()
{
	this.Seasons=Seasons;
}

}
public class ConstructorSeason {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
season s=season.SUMMER;
System.out.println(s);
	}

}
