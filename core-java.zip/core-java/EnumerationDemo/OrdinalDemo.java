package EnumerationDemo;

public class OrdinalDemo {
enum Directions{
	EAST,WEST,NORTH,SOUTH;
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
for(Directions d:Directions.values())
{
	System.out.println(d);
}
System.out.println("value"+Directions.NORTH);
System.out.println("Values of "+Directions.valueOf("WEST"));
System.out.println("Index of :"+Directions.valueOf("NORTH").ordinal());
	}

}
