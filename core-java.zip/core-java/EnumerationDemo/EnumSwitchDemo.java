package EnumerationDemo;
enum car{
	LAMBORGINI,TATA,AUDI,POCSH,BENTLY;
}
public class EnumSwitchDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
car c= car.AUDI;

switch(c)
{
case LAMBORGINI:
	System.out.println("You chosse lambo");
	System.out.println("Value "+car.valueOf("LAMBORGINI"));
	System.out.println("Index "+car.valueOf("LAMBORGINI").ordinal());
break;
case TATA:
	System.out.println("You chose TATA");
	System.out.println("Value "+car.valueOf("TATA"));
	System.out.println("Index "+car.valueOf("TATA").ordinal());
	break;
case AUDI:
	System.out.println("You chose audi OOOO");
	System.out.println("Value "+car.valueOf("AUDI"));
	System.out.println("Index "+car.valueOf("AUDI").ordinal());
	break;
case BENTLY:
	System.out.println("You chose Bently");
	System.out.println("Value "+car.valueOf("BENTLY"));
	System.out.println("Index "+car.valueOf("BENTLY").ordinal());
	break;
case POCSH:
	System.out.println("You chose posch");
	System.out.println("Value "+car.valueOf("POCSH"));
	System.out.println("Index "+car.valueOf("POSCH").ordinal());
	break;
	default:
		System.out.println("UnKnown model ");
		break;
}
	}

}
