package AbstractAssign;

abstract class GeneralBank{
	
	abstract public int getSavingsInteresrRate();
	abstract double getFixedDepositInterestRate();
}
class ICICIBank extends GeneralBank{
	public int getSavingsInteresrRate()
	{int x;
		return 4;
	}
	public double getFixedDepositInterestRate()
	{
		return 8.5;
	}
}
class SBIBank extends GeneralBank{
	public int getSavingsInteresrRate()
	{
		return 4;
	}
	public double getFixedDepositInterestRate()
	{
		return 7;
	}
}
public class Bank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("----------------------Case1---------------------");
ICICIBank i=new ICICIBank();
double fd=i.getFixedDepositInterestRate();
int s=i.getSavingsInteresrRate();
System.out.println("the Interest rate of ICICI Bank for Saving is "+s+" and for fd is "+fd);

System.out.println();
System.out.println("----------------------Case2-------------------------");
SBIBank sb=new SBIBank();
double fd1=sb.getFixedDepositInterestRate();
int s1=sb.getSavingsInteresrRate();
System.out.println("the Interest rate of ICICI Bank for Saving is "+s1+" and for fd is "+fd1);


System.out.println("----------------------Case3------------------------");
/*GeneralBank g=new GeneralBank();
double fd2=g.getFixedDepositInterestRate();
int s2=g.getSavingsInteresrRate();
System.out.println("the Interest rate of ICICI Bank for Saving is "+s2+" and for fd is "+fd2);
*/
	}

}
