package AbstractAssign;
abstract class Compartment
{
	abstract void notice();
}
class FirstClass extends Compartment
{
	void notice()
	{
		System.out.println("Welcome to First class Compartment");
	}
}
class Ladies extends Compartment
{
	void notice()
	{
		System.out.println("Welcome to Ladies  Compartment");
	}
}
class  General extends Compartment
{
	void notice()
	{
		System.out.println("Welcome to General class Compartment");
	}
}
class Luggage extends Compartment
{
	void notice()
	{
		System.out.println("Welcome to Luggage Compartment");
	}
}
public class Railway {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Compartment A []= new Compartment[10];
		int randnum=0;
		for (int i=0; i<10; i++)
		{
		randnum=0;
		while ((randnum<1) || (randnum>4))
		{
			randnum = (int) (Math.random() *4 + 1);
		}
		switch (randnum)
		{
		case 1: { A[i] = new FirstClass();
					break;
					}
		case 2: { 
			A[i] = new Ladies();
			break;
			}
		case 3: {
			A[i] = new General(); 
			break; 
			}
		case 4: { 
			A[i] = new Luggage(); 
			break; 
			}
		}
		System.out.print(" object # " + (i+1) +" "); A[i].notice();
		}
	}

}
