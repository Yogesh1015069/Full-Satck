package Mangament;


import Mangament.user;

import  static Mangament.user.returnBook;
import static Mangament.user.*;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

class Books{
	private int BookNumber;
	private String Bookname;
	static ArrayList<String> BooKNamesSearch =new ArrayList<>();	
	static void BookSearch(String Bookname)
	{
		System.out.println(Bookname);
		boolean result=false;
		Iterator<String> i=BooKNamesSearch.iterator();
		while(i.hasNext())
		{
			String s=i.next();
			
			if(s.equals(Bookname))
			{
				result=true;
				break;
				
			}
			
		}
		if(result)
		{
			System.out.println("Found");
		}
		else
		{
			System.out.println("Not Found");
		}
		
	}
	private double price;
	public int getBookNumber() {
		return BookNumber;
	}

	public void setBookNumber(int bookNumber) {
		BookNumber = bookNumber;
	}

	public String getBookname() {
		return Bookname;
	}

	public void setBookname(String bookname) {
		Bookname = bookname;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	private String date;
	Books()
	{
	super();	
	}
	
	Books(int BookNumber,String Bookname,double price,String date)
	{
		super();
		addBookname(Bookname);
		this.Bookname=Bookname;
		this.BookNumber=BookNumber;
		this.date=date;
		this.price=price;
	}
	private void addBookname(String bookname2) {
		BooKNamesSearch.add(bookname2);
		
	}

	Books(int BookNumber,String Bookname,double price)
	{
		super();
		BooKNamesSearch.add(Bookname);
		this.Bookname=Bookname;
		this.BookNumber=BookNumber;
		this.price=price;
		
	}
	public String toString() {
		return "Book Number "+BookNumber+" Book Name "+Bookname+"Price is "+price;
	}
}

public class LibaryMangementSystem extends user {

	private static void searchBook() throws IOException {
		// TODO Auto-generated method stub
		 InputStreamReader r=new InputStreamReader(System.in);    
		    BufferedReader br=new BufferedReader(r);            
		    System.out.println("Enter the book name");
		    String name=br.readLine();    
		Books.BookSearch(name);
	}
	private static void adminMenu() throws IOException  {
		System.out.println("------------Welcome admin----------------");
		System.out.println("1.Add Books");
		System.out.println("2.View Issued Books");
		System.out.println("3.All Books in Library");
		System.out.println("4.Search Book");
		System.out.println("5.Main Menu");
		System.out.println("6.Register Student ");
		System.out.println("7.Exit");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		do {
			switch(choice)
			{
			case 1:
				addBook();
				adminMenu();
				break;
			case 2:
				user.allissue();
				adminMenu();
				break;
			case 3:
				allBooks();
				adminMenu();
				break;
			case 4:
				searchBook();
				adminMenu();
				break;
			case 5:
				mainMenu();
				break;
			case 6:
				studentlogin.addStudent();
				adminMenu();
			case 7:
				System.exit(0);
				break;
		 default:
				System.out.println("-------Invalid Input------");
				
			}
			
		} while(choice >0 &&choice<8);
	}
	
	private static  void userMenu() throws IOException
	{
		System.out.println("-----------Welcome User------------");
		
		System.out.println("1.To issue a book");
		System.out.println("2.To return a book");
		System.out.println("3.To print the book details");
		System.out.println("4.All Books in Libary");
		System.out.println("5.To go Main Menu");
		System.out.println("6.To exit");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		do {
			switch (choice) {
			case 1:
				issueBook();
				userMenu();
				break;
			case 2:
				returnBook();
				userMenu();
				break;
			case 3:
				printBookDetails();
				userMenu();
				break;
			case 4:
				allBooks();
				userMenu();
				break;
			case 5:
				mainMenu();
				break;
			case 6:
				System.exit(0);
				break;	
			default:
				System.out.println("Invalid input");
				break;
			}
			
			choice = sc.nextInt();
		} while (choice > 0 && choice < 7);
	}
	
	




	private static void printBookDetails() throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b1=new BufferedReader(i);
		System.out.println("Enter the Book id");
		int bookId = Integer.parseInt(b1.readLine());
		for(Object k:b) {
			if(((Books)k).getBookNumber()==bookId) {
				System.out.println("Book Id "+bookId+" Bookname "+((Books)k).getBookname()+" Price "+((Books)k).getPrice());
			}
		}
	}




	public static void mainMenu() throws IOException
	{
		System.out.println("Library Management System");
		System.out.println("1.Admin Login");
		System.out.println("2.User Login");
		System.out.println("3.Exit");

		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		do {
			switch(choice)
			{
			case 1:
				checkLogIn();
				break;
			case 2: 
				stud.add(new studentlogin(123,"Yogesh"));
				stud.add(new studentlogin(321,"Piyush"));
				checkStudent();
				userMenu();
			case 3:
				System.exit(0);
				break;
				default:
					System.out.println("Ivalid Input");
					break;
			}
		}
		while(choice>0&&choice<4);
	}
	private static void checkLogIn() throws IOException {
		// TODO Auto-generated method stub
		/*Console r=System.console();
		String usrname=r.readLine();
		char[] passwrd=r.readPassword();
		*/
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the admin name");
		String usrname=sc.next();
		System.out.println("Enter the password");
		String passwrd=sc.next();
		if((usrname.equals("admin"))&& passwrd.equals("admin"))
		{
			System.out.println("Log in Sucees full");
			adminMenu();
		}
		else {
			System.out.println("Invalid Password");
			mainMenu();
		}
	}
	private static void checkStudent() throws IOException {
InputStreamReader s=new InputStreamReader(System.in);
BufferedReader b= new BufferedReader(s);
System.out.println("Enter your Student id");
int r=Integer.parseInt(b.readLine());
System.out.println("enter your name");
String name=b.readLine();
if(studentlogin.checkloginStudent(r,name))
{
	System.out.println("Login Succesful");
	userMenu();
}
else {
	System.out.println("Login Invalid Kindly Register");
	System.out.println("--------------------------------");
	mainMenu();
}
		}
	static ArrayList <Object> b=new ArrayList<>();
	static ArrayList<Object> stud=new ArrayList<>();
	static void addBook() throws NumberFormatException, IOException{
		InputStreamReader s=new InputStreamReader(System.in);
		BufferedReader bf= new BufferedReader(s);
		System.out.println("enter the Book Number");
		int number=Integer.parseInt(bf.readLine());
		System.out.println("enter the Book name");
		String name=bf.readLine();
		System.out.println("enter the Book price ");
		double price=Double.parseDouble(bf.readLine());
		 b.add(new Books(number,name,price));
		
			System.out.println("Book add Succesfully");
		
		//	System.out.println("Error in Adding Book");
		
	}
	static void allBooks()
	{
		Iterator<Object> i=b.iterator();
	while(i.hasNext())
	{
		System.out.println(i.next());
	}
	}
	static void viewIssuedBooks() {
		
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		b.add(new Books(110,"Harry Potter",50.0));
		b.add(new Books(220,"Wings of Fire",60.0));
		b.add(new Books(330,"Experiments With Truth",40.0));
		issuedbooks1.add(new Issuedetails(110,"Harry Potter",50.0,"04-06-2022"));
		
		mainMenu();
		
		
		
	}
	

	
}

