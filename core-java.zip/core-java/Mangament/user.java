 package Mangament;

import java.awt.List;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;
class Issuedetails {
	
	private int bookNumber;
	private String name;
	
	private String issueDate;
	private String returnDate;
	private double price;
	public String toString()
	{
		return "Book Number "+bookNumber+" Book Name "+name+" Issued Date "+issueDate+" Price "+price+" rs";
	}
	Issuedetails(int bookNumber,String name,double price,String issueDate)
	{
		this.bookNumber=bookNumber;
		this.name=name;
		this.price=price;
		this.issueDate=issueDate;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getBookNumber() {
		return bookNumber;
	}

	public void setBookNumer(int bookNumber) {
		this.bookNumber = bookNumber;
	}

	

	public String getIssueDate() {
		return issueDate;
	}

	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

}
class studentlogin {
	int Studentid;
	String Studentname;
	static HashMap<Integer,String> map=new HashMap<Integer,String>();
	static boolean checkloginStudent(int r,String name){
		Set<Entry<Integer, String>> s=map.entrySet();
		
		Iterator<Entry<Integer,String>> i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			if((entry.getKey().equals(r))&&(entry.getValue().equals(name)))
			{
				return true;
			}
		}
		return false;
		
	}
	studentlogin(int Studentid,String name)
	{
		super();
		map.put(Studentid,name);
		this.Studentid=Studentid;
		this.Studentname=name;
	}
	static void addStudent() throws NumberFormatException, IOException
	{
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b=new BufferedReader(i);
		System.out.println("Enter the Id to assign");
		int id=Integer.parseInt(b.readLine());
		System.out.println("Enter the name to register");
		String name=b.readLine();
		map.put(id,name);
		System.out.println("Student Registered");
	}
	public String toString() {
		return "Student id "+Studentid+"Student Name "+Studentname;
		
	}
}
public class user {
static ArrayList<Object> issuedbooks1=new ArrayList<>();
private int totalBookAllowed = 2;
private static int noOfBookIssued=0;
public static int getNoOfBookIssued() {
	return noOfBookIssued;
}
public static  void setNoOfBookIssued(int noOfBook) {
	noOfBookIssued = noOfBook;
}	
static void allissue() {
		Iterator i=issuedbooks1.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}
	
	public static void returnBook() throws NumberFormatException, IOException {
		System.out.println("Enter studentId ");
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b1=new BufferedReader(i);
		int id = Integer.parseInt(b1.readLine());
		System.out.println("Enter the Book id");
		int bookId = Integer.parseInt(b1.readLine());
		System.out.println("Enter today's date in dd-mm-yyyy only");
		String currentdate=b1.readLine();
		for (Object b : issuedbooks1) {
			if (((Issuedetails) b).getBookNumber() == bookId) {
				String issueDate = ((Issuedetails) b).getIssueDate();
				double price=((Issuedetails) b).getPrice();
				System.out.println(price);
				System.out.println(issueDate);
				findDifference(issueDate, currentdate,price);
				//issuedbooks1.remove(((Issuedetails) b));
			}
		}

	}
	
	private static void findDifference(String issueDate, String currentdate ,double price) {
		// TODO Auto-generated method stub
		 SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		 
		 try {
			  
	            // parse method is used to parse
	            // the text from a string to
	            // produce the date
	            java.util.Date d1 = sdf.parse(issueDate);
	            java.util.Date d2 = sdf.parse(currentdate);
	            long difference_In_Time=d2.getTime() - d1.getTime();
				long diffDays= TimeUnit.MILLISECONDS.toDays(difference_In_Time)% 365;

				if (diffDays > 10) {
					double fine = (int) (diffDays - 10);
					fine = (fine * 10)+price;
					System.out.println("Total Price to pay " + fine + " Rs.");
	}
				else {
					System.out.println("Total Price to pay " + price + " Rs.");
				}
		 }
				
		 catch(Exception e)
		 {
			 System.out.println(e);
		 }
	}
	protected static void issueBook() throws IOException {
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b1=new BufferedReader(i);
		System.out.println("Enter Booknumber, name  date and price");
		System.out.println("enter Book Number");
		int bookNumber = Integer.parseInt(b1.readLine());
		System.out.println("enter Book Name");
		String name = b1.readLine();
		System.out.println("enter price");
		double price=Double.parseDouble(b1.readLine());
		System.out.println("enter date in dd/mm formate");
		String issueDate = b1.readLine();
		
		int x=getNoOfBookIssued();
		if(x>2)
		{
			System.out.println("More than allowed Books can not be Registered");
		
		}
		else {
			issuedbooks1.add(new Issuedetails(bookNumber,name,price,issueDate));
		setNoOfBookIssued(x++);
		}
	System.out.println("add succesfully");
	}
	
	
	
}
