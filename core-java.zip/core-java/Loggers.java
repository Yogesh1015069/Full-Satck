import java.util.logging.Level;
import java.util.logging.Logger;
class Wombat{
	static void sneeze(){
		System.out.println("He is sneezing");
	}
static void	nose(){
		System.out.println("nose");
	}
}
public class Loggers {
	 private static Logger logger = Logger.getLogger("com.wombat.nose");
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 logger.fine("doing stuff");
	        try {
	            Wombat.sneeze();
	        } catch (Exception ex) {
	            // Log the exception
	            logger.log(Level.WARNING, "trouble sneezing", ex);
	        }
	        logger.fine("done");
	}

}
