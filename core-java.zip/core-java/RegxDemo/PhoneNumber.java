package RegxDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class PhoneNumber {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
InputStreamReader i=new InputStreamReader(System.in);
BufferedReader b=new BufferedReader(i);
System.out.println("Enter the number to check");
String s=b.readLine();
boolean b1=Pattern.matches("[0-9]{10}",s);
System.out.println("number is valid "+b1);
System.out.println("Enter the mail to check");
	String email=b.readLine();
	boolean b2=Pattern.matches("(.+)(@gmail.com)",email);
	System.out.println(b2);
	
	System.out.println("Enter the url ");
	String url=b.readLine();
	boolean b3=Pattern.matches("((http|https)://)(www.)?"+"(.+)"+"(.com)",url);
	System.out.println(b3);
	System.out.println("enter the date");
	
	String date=b.readLine();
	boolean b4=Pattern.matches("[0-9]{2}"+"(/|-)"+"[0-9]{2}"+"(/|-)"+"[0-9]{4}",date);
	System.out.println(b4);
	
	}

}
