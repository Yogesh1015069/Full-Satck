package RegxDemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class ExtractNumber {

	public static void main(String[] args) throws IOException {
		InputStreamReader s=new InputStreamReader(System.in);
		BufferedReader b= new BufferedReader(s);
		System.out.println("Enter the Strinhg");
		String s1=b.readLine();
		String re="";
		boolean b2=false;
		for(int i=0;i<s1.length();i++)
		{
			char ch=s1.charAt(i);
			String s5=Character.toString(ch);
			if(b2=Pattern.matches("[0-9]",s5)){
				re=re+s5;
			}
		}
		System.out.println(Integer.parseInt(re));
	}

}
