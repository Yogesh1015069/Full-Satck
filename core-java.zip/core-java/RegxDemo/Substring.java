package RegxDemo;

public class Substring {
public static void main(String[]args) {
	String s="hii hello world";
	String subs="hello";
	boolean re=s.matches(subs);
	System.out.println(re+" "+subs);
}
}
