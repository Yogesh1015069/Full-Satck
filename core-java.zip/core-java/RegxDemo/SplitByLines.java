package RegxDemo;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SplitByLines {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b=new BufferedReader(i);
		String s="Hii\n this is yogesh\n sahu";
		String []sarray=s.split("\\n");
		System.out.println(sarray);
		for(String re:sarray)
		{
			System.out.print(re);
			System.out.print(",");
		}
		//sarray.forEach((s2)->{System.out.print(s2;)});
	}

}
