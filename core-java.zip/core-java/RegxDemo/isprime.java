package RegxDemo;

import java.util.Scanner;

public class isprime {
	public static boolean isPrime(int n) {
	    return !new String(new char[n]).matches(".?|(..+?)\\1+");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter the number to check");
int n=sc.nextInt();
System.out.println(isPrime(n));

	}

}
