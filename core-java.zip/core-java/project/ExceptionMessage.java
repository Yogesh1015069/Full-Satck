package project;

public class ExceptionMessage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			int a=100;
			int b=0;
			int c=0;
			//c=a/b;
			System.out.println(c);
		}
		/*catch(ArithmeticException e)
		{
	//e.printStackTrace();
			//System.out.println(e);
			System.out.println(e.getMessage());
		}*/
		finally
		{
			System.out.println("I am in Finall block");
		}
	}

}
