package project;

import Mypackage.Start;

public class demo {
	public static void main(String[] args) {
		Start ob=new Start();
		ob.display();
		ob.Vehicle();
		
	}

}
