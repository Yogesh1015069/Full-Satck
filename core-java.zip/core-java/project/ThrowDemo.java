package project;

import java.util.Scanner;

class VoteEligiblity extends RuntimeException
{
	VoteEligiblity(String s)
	{
		super(s);
	}
}
public class ThrowDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Age");
		int age=sc.nextInt();
		try
		{
		if(age<18)
		{
			throw new VoteEligiblity("You are not eligible for voting");
			//System.out.println("after throw");
		}
		else {
			System.out.println("You can Vote");
		}
		}
		catch(VoteEligiblity e)
		{
			e.printStackTrace();
		}
		System.out.println("Normal Termination");
	}

}
