package project;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

public class FileStreamBuffer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
File f=new File("C:\\Users\\yosah\\xyz.txt");
FileInputStream s=new FileInputStream("C:\\Users\\yosah\\xyz.txt");
BufferedInputStream b=new BufferedInputStream("C:\\Users\\yosah\\xyz.txt");
	}

}
