package project;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileInputOutputStreamDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream in=new FileInputStream("C:\\\\Users\\\\yosah\\\\abc.txt");
	FileOutputStream op=new FileOutputStream("C:\\Users\\yosah\\xyz.txt");
	int c;
	while((c=in.read())!=-1)//=yash -1 last m ayega
	{
	//	op.write(c);
		System.out.println((char)(c));
	}
	in.close();
	op.close();
	}

}
