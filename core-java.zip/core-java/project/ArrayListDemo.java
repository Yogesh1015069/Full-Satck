package project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

public class ArrayListDemo {

	public static void main(String[] args) {
		/*// TODO Auto-generated method stub
		ArrayList a=new ArrayList();
		a.add(10);
		a.add("yash");
		a.add('j');
		System.out.println(a);
		HashSet e=new HashSet();
		e.add("technologies");
		e.add(20);
		
		System.out.println(e);
		HashMap  m=new HashMap();
		m.put(1000, "in hash");
		m.put(1001, "yashu");
		System.out.println(m);
		*/
		  ArrayList<String> animals = new ArrayList<>();
		    animals.add("Cow");
		    animals.add("Cat");
		    animals.add("Dog");
		    System.out.println("ArrayList: " + animals);
		   
		    // iterate using for-each loop
		    System.out.println("Accessing individual elements:  ");

		    for (String language : animals) {
		      System.out.print(language);
		      System.out.print(", ");
		      //iterate through iterator
		    }
		      System.out.println("Elemnt at index 1 is "+animals.get(0));
		      Collections.sort(animals);
		      Iterator e =animals.iterator();
		      while(e.hasNext())
		      {
		    	  System.out.println(e.next());
		      }
		    
	}

}
