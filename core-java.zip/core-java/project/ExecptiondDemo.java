package project;

public class ExecptiondDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Yash");
		System.out.println("Technologies");
		System.out.println("hello");
		try {
		System.out.println(100/0);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		System.out.println("bye");
	}

}
