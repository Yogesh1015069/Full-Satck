package project;

import java.io.Console;

public class ConsoleDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str;
		char ch[];
		Console ob=System.console();
		System.out.print("Enter Username ");
		 if (ob == null) {
	            System.out.println("No console available");
	            return;
	        }
		str=ob.readLine();
		System.out.print("Enter Password");
		ch=ob.readPassword();
		String a=String.valueOf(ch);
		System.out.print("Username: "+str+"password: "+ch);
		System.out.print("Actual password"+a);
	}

}
