package project;
//static class Outer{
/*
void show1() {
		System.out.println("hello");
	}
*/
class Outer{
	//static class Inner{
	//protected class Inner it works fine
	//private class Inner{//if private it shows an error Outer.inner is not vissible
	class Inner{	
	void show() {
			System.out.println("Outer Show");
		}
	}
}
public class InnerOuterClass {

	public static void main(String[] args) {
	
		 // if inner class is not static
		Outer b=new Outer();
		Outer.Inner oi= b.new Inner();
		oi.show();
	
	
/*
		//if inner class is Static
		Outer.Inner oi= new Outer.Inner();
		oi.show();

*/
		
/*
 		// if outer class is static
 
		Outer b=new Outer();
		b.show1();
*/		
		
		
	}

}
