package project;
import advance.src.Mypackage.Start;
public class demopack {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Mypackage.Start ob=new Mypackage.Start();
ob.display();
ob.Vehicle();
	}

}
