package project;

import java.io.FileInputStream;

public class ExceptionChecked {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		FileInputStream f=new FileInputStream("D:/xyz.txt");
			/*String s=null;
			System.out.println(s.length());*/
		System.out.println("hello");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		System.out.println("bye");
	}

}
