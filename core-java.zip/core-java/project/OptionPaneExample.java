package project;
import javax.swing.JFrame;
import javax.swing.JOptionPane;  
public class OptionPaneExample {
	 
	  
	OptionPaneExample(){  
		JFrame  f=new JFrame();   
	    String name=JOptionPane.showInputDialog(f,"Enter Name");      
	    JOptionPane.showMessageDialog(null, name);
	}  
	public static void main(String[] args) {  
	    new OptionPaneExample();  
	}  
	
}
