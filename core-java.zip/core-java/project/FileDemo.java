package project;

import java.io.File;

import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		//File f=new File("C:\\Users\\yosah\\abc.txt");
		File f=new File("C:\\Users\\yosah\\xyz.txt");
		f.createNewFile();	//for Creating new File	
		System.out.println(f.exists());//check Existing 
				System.out.println(f.canWrite());//can we write
				System.out.println(f.length());//get file size
				System.out.println(f.getName());//file naem
				f.delete();
	}

}
