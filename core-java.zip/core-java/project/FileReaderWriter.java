package project;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReaderWriter {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		File f=new File("C:\\\\Users\\\\yosah\\\\abc.txt");
		f.createNewFile();
		FileWriter w=new FileWriter(f);
		w.write("Welcome to Yash");
		w.close();
		FileReader r=new FileReader(f);
		char [] a=new char[20];
		r.read(a);
		for(char c:a)
		{
			System.out.print(c);
		}
		r.close();		
		
	}

}
