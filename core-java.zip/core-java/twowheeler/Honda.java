package twowheeler;
import com.automobile.vehicle;	
	public class Honda extends vehicle{
		String modelName;
		 String registrationNumber;
		String ownerName;
		 int speed;
		
		public Honda(String modelName, String registrationNumber, String ownerName, int speed) {
			this.modelName = modelName;
			this.registrationNumber = registrationNumber;
			this.ownerName = ownerName;
			this.speed = speed;
		}
		public int getSpeed()
		{
			return speed;
		}
		public void cdplayer() {
			System.out.println("You can Access Cd ");
		}

		@Override
		public String getModelName() {
			// TODO Auto-generated method stub
			return modelName;
		}

		@Override
		public String getRegistrationNumber() {
			// TODO Auto-generated method stub
			return registrationNumber;
		}

		@Override
		public String getOwnerName() {
			// TODO Auto-generated method stub
			return ownerName;
		}
		
		
	}

