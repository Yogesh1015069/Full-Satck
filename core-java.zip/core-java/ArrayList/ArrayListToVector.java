package ArrayList;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.Vector;
public class ArrayListToVector {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> year= new ArrayList<String>();
		year.add("January");
		year.add("Febuary");
		year.add("March");
		year.add("April");
		year.add("June");
		year.add("July");
		year.add("August");
		year.add("September");
		year.add("October");
		year.add("November");
		year.add("December");
		System.out.println("by simple printing list "+year);
		System.out.println("BY Iterator");
		System.out.println();
		Iterator i=year.iterator();
		while(i.hasNext())
		{
			System.out.print(i.next());
			System.out.print(" ");
		}
		System.out.println();
		System.out.println("Vector");
		Vector<String> years=new Vector<>();
		years.addAll(year);
		for(String s:years)
		{
			System.out.print(s);
			System.out.print(" ");
		}
	}

}
