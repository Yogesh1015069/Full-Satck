package ArrayList;

import java.util.Iterator;
import java.util.Vector;
class Employee
{
	private String name;
	private String department;
	private int empid;
	
	Employee(int empid,String name,String Department){
		super();
		this.empid=empid;
		this.name=name;
		this.department=department;
	}
public String toString(){
		
	return "Employee id "+empid+" name "+name+" department "+department;
	}

}
public class EmployeeObjects {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector<Object> emp=new Vector<>();

		emp.add(new Employee(100,"yogesh","cse"));
		emp.add(new Employee(200,"piyush","civil"));
		emp.add(new Employee(300,"Sameer","Eco"));
		emp.add(new Employee(400,"Shubhum","Science"));
		emp.add(new Employee(500,"uttam","maths"));
		Iterator i=emp.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}
	}

}
