package ArrayList;

import java.util.ArrayList;
import java.util.Scanner;
class TypeMissMatch extends RuntimeException{
	TypeMissMatch(String s)
	{
		super(s);
	}
}
class MyArrayList<O> extends ArrayList<O> {

	public boolean add(O a) {
		if (a instanceof Integer||a instanceof Double||a instanceof Float )
		{
			super.add(a);
			return true;
		}
		else
		{
		throw new TypeMissMatch("You enter a character or String");
		}
	}
	
}
public class ArrayListSpecificDataTypes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
MyArrayList<Object>  a= new MyArrayList<>();
	try {
	a.add(1);
	a.add(2.0);
	a.add(1.4F);
	a.add("abc");
	}
	catch(TypeMissMatch e)
	{
		System.out.println(e);
	}
	}
}
