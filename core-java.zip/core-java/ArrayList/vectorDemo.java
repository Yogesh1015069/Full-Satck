package ArrayList;

import java.util.Vector;

import java.util.Iterator;

public class vectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Vector <String > v=new Vector<String>();
		v.add("y");
		v.add("a");
		v.add("s");
		v.add("h");
		System.out.println("Now Using addElement");
		v.addElement("Technologies");
		Iterator i=v.iterator();
		while(i.hasNext())
		{
			System.out.print(i.next());
		}
	}

}
