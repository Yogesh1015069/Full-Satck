package ArrayList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.ListIterator;

public class printYear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<String> year= new ArrayList<String>();
year.add("January");
year.add("Febuary");
year.add("March");
year.add("April");
year.add("June");
year.add("July");
year.add("August");
year.add("September");
year.add("October");
year.add("November");
year.add("December");
System.out.println("by simple printing list "+year);
System.out.println("BY Iterator");
System.out.println();
/*Iterator e =year.iterator();
while(e.hasNext())
{
	  System.out.print(e.next());
	  System.out.print(",");
}
System.out.println();
System.out.println("By for Each Loop");
System.out.println();
for(String s:year)
{
	System.out.print(s);
	System.out.print(",");
}*/
ListIterator li=year.listIterator();
li.next();
li.next();
while(li.hasPrevious())
{
	System.out.println(li.previous());
	System.out.println(",");
}
li.set("jan");
System.out.println(year);
	}

}
