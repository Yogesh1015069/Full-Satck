package debugger;

public class debugdeno {
static void show() {
	System.out.println("this is Yogesh ");
}
	public static void main(String[] args) {
		// TODO A
		uto-generated method stub
System.out.println("Welcome to Yash Technologies");
int x=9;
show();
if(x<10)
{
	System.out.println("it is single digit");
}
else
{
	System.out.println("it is greater than 10");
}
	}

}
