package HashSets;

import java.util.Collection;
import java.util.Collections;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.Scanner;
public class TreeSET {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet<String > set= new TreeSet<String>();
		set.add("Yogesh");    
        set.add("Piyush");    
        set.add("Sameer");   
        set.add("Uttam");  
        set.add("Shubham"); 
        System.out.println(set);
        System.out.println("a.Reverse the elements form Collection");
        
        Collection <String >c=new TreeSet<>(Collections.reverseOrder());
        c.addAll(set);
        System.out.println(c);
        System.out.println("b.iterate throuh the TreeSet ");
       Iterator  i=set.iterator();
       while(i.hasNext()) {
    	   System.out.print(i.next());
    	   System.out.print(",");
        }
       Scanner sc=new Scanner(System.in);
      System.out.println();
       System.out.println("C.Check particular element exist or not");
       System.out.println("enter the string to Search");
       String s=sc.next();
       Iterator i1=c.iterator();
       boolean result=false;
       while(i1.hasNext())
       {
    	   if(i1.next().equals(s))
    	   {
    		   
    		   result =true;
    		   break;
    	   }
    	   
       }
       if(result)
       {
    	   System.out.println();
    	   System.out.println("Querry matched");
       }
       else
       {
       System.out.println("Querry mismatched");
       }
        
	}

}
