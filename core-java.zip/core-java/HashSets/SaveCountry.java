package HashSets;

import java.util.HashSet;
import java.util.Iterator;

class Country{
	HashSet<String> h1=new HashSet<>();
public 	HashSet<String> saveCountryNames(String CountryName)
	{
		h1.add(CountryName);
		return h1;
	}
public String getcountry(String CountryName) {
	Iterator<String> i=h1.iterator();
	while(i.hasNext())
	{
		if(i.next().equals(CountryName))
		{
			return CountryName;
			
		}
	}
	return null;
}
	
}
public class SaveCountry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Country c=new Country();
		c.saveCountryNames("India");
		c.saveCountryNames("China");
		c.saveCountryNames("Russia");
		c.saveCountryNames("Srilanka");
		System.out.println("India "+c.getcountry("India"));
		System.out.println("Nepal "+c.getcountry("Nepal"));
	}

}
