package HashSets;

import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class hasDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  HashSet<String> set=new HashSet();  
          set.add("Yogesh");    
          set.add("Piyush");    
          set.add("Sameer");   
          set.add("Uttam");  
          set.add("Shubham");  
          Iterator<String> i=set.iterator();  
          while(i.hasNext())  
          {  
          System.out.println(i.next());  
          }  
        /*  System.out.println("After ading the same elementy i.e. one");
          set.add("One");
          for(String s:set)
          {
        	  System.out.print(s);
        	  System.out.print(",");
          }
          System.out.println();
          System.out.println("Adding Null values to the set");
          set.add(null);
          set.add(null);
          System.out.println("after adding two null values");
         for(String s:set)
         {
        	 System.out.print(s);
        	 System.out.print(" ");
         }*/
          
	}

}
