package Mypackage;

public class Start {
	public void display()
	{
		System.out.println("I am in display");
	}
	public void Vehicle() {
	System.out.println("Is it Bs4 or Bs6");	
	}

}
