package Ques;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

public class SortMapOnKey {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap <Integer,String> m=new HashMap<Integer,String>();
		m.put(10, "yogesh");
		m.put(100, "piyush");
		m.put(9, "Uttam");
		m.put(8, "Sameer");
		Iterator<Integer> i=m.keySet().iterator();
	System.out.println("Before Sorting");
	while(i.hasNext())
	{
		int key=(int)i.next();
		System.out.println("roll no "+key+" name "+m.get(key));
	}
	System.out.println();
	Map<Integer,String> tm=new TreeMap<Integer,String>(m);
	Iterator itr=tm.keySet().iterator();
	while(itr.hasNext())
	{
		int key=(int)itr.next();
		System.out.println("roll no "+key+" name "+m.get(key));
	}
	}

}
