package Ques;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;


public class StatesOfIndia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties prop=new Properties();
		prop.setProperty("Chhattisgarh","Raipur");
		prop.setProperty("Maharastra", "Mumbai");
		prop.setProperty("Odisha", "Khorda");
		Set<Entry<Object,Object>> map= prop.entrySet();
		Iterator <Entry<Object,Object>> i=map.iterator();
		while(i.hasNext())
		{
			Entry<Object,Object> e=i.next();
			System.out.println(e);
		}

	}

}
