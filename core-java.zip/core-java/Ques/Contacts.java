package Ques;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class ContactList{
	HashMap<String,Integer> contact=new HashMap<String,Integer>();
	void addContact(String name,Integer number) {
		contact.put(name, number);
	}
	void removeContacts(String name) {
		contact.remove(name);
		System.out.println("Contacts "+name+" removed");
	}
	public String toString(){
		return "ContactList "+contact;
	}
	boolean contactnameExist(String name) {
		Set<Entry<String, Integer>> s=contact.entrySet();
		Iterator <Entry<String,Integer>>i=s.iterator();
		while(i.hasNext())
		{
			if(i.next().getKey().equals(name))
			{
				
				return true;
				
			}
		}
		return false;
		
	}
	boolean contactNumberExist(Integer number) {
		Set<Entry<String, Integer>> s=contact.entrySet();
		Iterator <Entry<String,Integer>>i=s.iterator();
		while(i.hasNext())
		{
			if(i.next().getKey().equals(number))
			{
				
				return true;
				
			}
		}
		return false;
		
	}
	void allContacts() {
		Set<Entry<String,Integer>> s=contact.entrySet();
		Iterator<Entry<String,Integer>> i=s.iterator();
	while(i.hasNext())
	{
		Map.Entry<String,Integer> m=i.next();
		System.out.println(m);
	}
	}
}
public class Contacts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ContactList cont =new ContactList();
		cont.addContact("yogesh", 9829770);
		cont.addContact("mama", 9893930);
		cont.addContact("vijay", 91311174);
		cont.allContacts();
		System.out.println("Check Yogesh Number exis or not "+cont.contactnameExist("yogesh"));
		System.out.println("Delete  Vijay Number ");
		cont.removeContacts("vijay");
		cont.allContacts();
	}

}
