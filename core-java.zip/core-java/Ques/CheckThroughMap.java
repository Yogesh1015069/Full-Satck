package Ques;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class CheckThroughMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashMap<Integer,String> map=new HashMap<Integer,String>();
		map.put(10, "yash");
		map.put(11,"technologies");
		map.put(20,"yogesh");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the key to check");
		int key=sc.nextInt();
		Set s=map.entrySet();
		Iterator  i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			if(entry.getKey().equals(key))
			{
				System.out.println();
				System.out.println("Key Found Which is "+entry.getKey());
				break;
			}
			
		}
		System.out.println("enter the Value to Search");
		String value=sc.next();
		Iterator  i1=s.iterator();
		while(i1.hasNext())
		{
			Map.Entry entry=(Map.Entry)i1.next();
			if(entry.getValue().equals(value))
			{
				System.out.println();
				System.out.println("Value Found Which is "+entry.getValue());
				break;
			}
			
		}
		System.out.println("Iteration Through Map");
		Iterator  i2=s.iterator();
		while(i2.hasNext())
		{
			Map.Entry entry=(Map.Entry)i2.next();
			System.out.println("Key: "+entry.getKey()+" Value "+entry.getValue() );
		}
		
		
	}

}
