package Ques;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

class Country{
	HashMap<String,String> m1=new HashMap<String,String>();
	 HashMap<String, String> saveCountrycapital(String CountryName,String capital)
	{
		 m1.put(CountryName,capital);
		return m1;
	}
	 String getCapital(String CountryName)
	 {
		 return m1.get(CountryName);
	 }
	 String getCountry(String capital)
	 {
		 Set s=m1.entrySet();
		 Iterator i=s.iterator();
		 while(i.hasNext())
		 {
			 Map.Entry entry=(Map.Entry)i.next();
			 if(entry.getKey().equals(capital))
			 {
				 return "Country is"+entry.getKey();
			 }
		 }
		return "Country is not found";
	 }
	 HashMap<String,String> createMap(){
		 HashMap<String,String> m2=new HashMap<String,String>();
		 Set s=m1.entrySet();
		 Iterator i=s.iterator();
		 while(i.hasNext())
		 {
			 Map.Entry entry=(Map.Entry)i.next();
			 m2.put((String)entry.getValue(), (String)entry.getKey());
		
			 
		 }
		 return m2;
	 }
	 ArrayList<String> toArrayList(){
		 ArrayList<String> list = new ArrayList<>();
			
			Set<Entry<String, String>> set = m1.entrySet();
			Iterator<Entry<String, String>> it = set.iterator();
			
			while (it.hasNext()) {
				Map.Entry<String, String> me = it.next();
				list.add(me.getKey());
			}
			
			return list;
	 }
}
public class CountryMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Country c=new Country();
		c.saveCountrycapital("India","Delhi");
		c.saveCountrycapital("China", "Bejing");
		c.saveCountrycapital("Srilanka", "Colombo");
		System.out.println(c.toArrayList());
		System.out.println(c.getCountry("Delhi"));
		System.out.println(c.getCapital("Srilanka"));
		HashMap<String,String> m=c.createMap();
		System.out.println(m);
		

	}

}
