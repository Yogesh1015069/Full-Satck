package Ques;

import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;

public class QueueDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Queue<Integer> pq=new PriorityQueue<Integer>();
	pq.add(200);
	pq.add(100);
	pq.add(500);
	System.out.println(pq.peek());//100
	System.out.println(pq.poll());//100
	System.out.println(pq.peek());//200
	pq.remove();
	System.out.println(pq);
	Queue<Integer> li=new LinkedList<Integer>();
	li.add(3000);
	li.add(2000);
	li.add(1000);
	System.out.println(li.peek());
	System.out.println(li.poll());
	System.out.println(li.peek());
	li.poll();
	//in remove it is empty it will throw exception
	}

}
