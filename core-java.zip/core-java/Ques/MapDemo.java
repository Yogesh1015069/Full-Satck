package Ques;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<Integer,String> map=new HashMap<Integer,String>();
		map.put(10, "yash");
		map.put(11,"technologies");
		map.put(20,"yogesh");//keySet() Containg
		for(Map.Entry m:map.entrySet())//it Returns the set conatining all the keys and values
			System.out.println("Key: "+entry.getKey()+" Value "+entry.getValue() );
		
			/*HashMap map=new HashMap();
		map.put(10, "yash");
		map.put(11,"technologies");
		map.put(20,"yogesh");
		Set s=map.entrySet();
		Iterator  i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			System.out.println("Key: "+entry.getKey()+" Value "+entry.getValue() );
		}*/
	}

}
