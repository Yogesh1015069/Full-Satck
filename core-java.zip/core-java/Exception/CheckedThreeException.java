package Exception;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class CheckedThreeException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
FileInputStream f=new FileInputStream("D:/f1.txt");

Class.forName("com.automobile.demo");
ClassLoader.getSystemClassLoader().loadClass("com.automobile.demo");


		}
		catch(ClassNotFoundException e)
		{
			System.out.println(e);
		}
		catch(FileNotFoundException e)
		{
			System.out.println(e);
		}
		catch(IOException e)
		{
			System.out.println();
		}
		
	}

}
