package Exception;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MathOperation {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		int [] arr=new int[5];
		try {
		for(int i=0;i<5;i++) //Array Initialization
		{
		arr[i]=Integer.parseInt(br.readLine());
		}
		}
		catch(NumberFormatException e)
		{
			System.out.println(e);
		System.exit(0);
		}
		int sum=0;
		try {
	
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		System.out.println("the sum of the array is"+sum);}
		catch(Exception e)
		{
			System.out.println(e);
			System.exit(0);
		}
		try {
			int avg=sum/arr.length;
			System.out.println("the avg of the array "+avg);
		}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		
	}
	

}
