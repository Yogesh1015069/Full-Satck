package Exception;
import java.util.Scanner;
class Negative extends RuntimeException
{
	Negative(String s)
	{
		super(s);
	}
}
class Max extends RuntimeException
{
	Max(String s1)
	{
		super(s1);
	}
}
public class NumException {

	public static void display() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the student name");
		String s=sc.next();
		int arr[]=new int[3];
		int sum=0;
		System.out.println("enter the marks");
		for(int i=0;i<3;i++)
		{
			try {
				
			arr[i]=Integer.parseInt(sc.next());
			
			    }
			catch (NumberFormatException e)
			{
				System.out.println(e);
				System.exit(0);
			}
		}
			for(int i=0;i<3;i++)
			{
				try 
			{
				if(arr[i]<0)
				{
					
					throw new Negative("Marks are in negative");
						
				}
				else if(arr[i]>100)
				{
					
					throw new Max("Marks are beyond range");
				}
				else 
				{
					sum=sum+arr[i];
				}
				
			}
				catch(Negative e)
				{
					e.printStackTrace();
					System.exit(0);
				}
				catch(Max e)
				{
					e.printStackTrace();
					System.exit(0);
				}
				
			}
			try {
			System.out.println("the avg is "+sum/3);
			}
			catch(ArithmeticException e)
			{
				e.getStackTrace();
			}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
display();
display();


	}


	}


