package Exception;

import java.util.Scanner;

public class NumberFormat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner (System.in);
		int n;
		System.out.println("Enter the Array size");
			n=sc.nextInt();
			int arr[]=new int[n];
			System.out.println("enter the Array Elements");
			
		
			
			for(int i=0;i<n;i++)
			{
				try {
					
				arr[i]=Integer.parseInt(sc.next());
				
				}
				catch (NumberFormatException e)
				{
					System.out.println(e);
					System.exit(0);
					
				}
			}
			
			System.out.println("enter the index of Array ");
			int x=sc.nextInt();
			try {
				int a=arr[x];
				System.out.println("the array Element is "
						+ ""+a);
			}
			catch(ArrayIndexOutOfBoundsException e)
			{
				System.out.println(e);
			}
			
	}

}
