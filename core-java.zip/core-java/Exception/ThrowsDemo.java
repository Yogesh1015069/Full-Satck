package Exception;
import java.util.Scanner;
class M{
public int divide(int n1,int n2)throws ArithmeticException
{
	int q=n1/n2;
	return q;
}
	}
public class ThrowsDemo {
	
	public static void main(String[] args) throws ArithmeticException {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
	System.out.println("Enter two numbers");
	int n1=sc.nextInt();
	int n2=sc.nextInt();
	M d = new M();
	System.out.println(d.divide(n1,n2));
	}

}
