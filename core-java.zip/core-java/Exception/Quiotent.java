package Exception;
import java.util.Scanner;
class DivideByZeroException extends RuntimeException{
	DivideByZeroException(String s)
	{
		super(s);
	}
}
public class Quiotent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("Enter the Two Number ");
try
{
int n1=Integer.parseInt(sc.next());
int n2=Integer.parseInt(sc.next());
if(n2==0)
{
	throw new DivideByZeroException("DivideByZeroException Caught");
}
int q=n1/n2;
System.out.println("The Queotient is "+n1+"/"+n2+"="+q);
}
catch(NumberFormatException e)
{
	System.out.println(e);
	System.exit(0);
}
catch(DivideByZeroException e)
{
	System.out.println(e);
}
catch(ArithmeticException e)
{
	System.out.println(e);
}
finally
{
	System.out.println("Inside Finally Bolck");
}
}

}
