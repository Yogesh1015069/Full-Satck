package Exception;
import java.util.Scanner;
public class ArrayIndex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner (System.in);
int n;
System.out.println("Enter the Array size");
	n=sc.nextInt();
	System.out.println("enter the Array Elements");
	int arr[]=new int[n];
	for(int i=0;i<n;i++)
	{
		arr[i]=sc.nextInt();
	}
	System.out.println("enter the index of Array ");
	int x=sc.nextInt();
	try {
		int a=arr[x];
		System.out.println("the array Element is"+a);
	}
	catch(ArrayIndexOutOfBoundsException e)
	{
		System.out.println(e);
	}
	}

}
