package Exception;
import java.util.Scanner;
class InvalidCountryException extends RuntimeException{
	InvalidCountryException(String s)
	{
		super(s);
	}
}
public class UserRegistration {
	static void registerUser(String n,String c)
	{
		try
		{
			if(c.matches("India"))
			{
				System.out.println("User Registration Done Successfully");
			}
			else {
				throw new InvalidCountryException("User Outside India Registration Cannot Be Done");
			}
		}
		catch(InvalidCountryException e)
		{
			System.out.println(e);
		}
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the username");
	String n=sc.next();
	System.out.println("Enter Your Country");
	String c=sc.next();
	registerUser(n,c);
	}

}
