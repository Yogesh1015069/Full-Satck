package Exception;

import java.util.Scanner;

public class Square {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number ");
				String str = sc.next();
	        try{
	            int number = Integer.parseInt(str);
	            System.out.println(number*number); // output = 25
	        }
	        catch (NumberFormatException ex){
	            ex.printStackTrace();
	        }
	}

}
