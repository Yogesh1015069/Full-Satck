package Exception;
import java.util.InputMismatchException;

import java.util.Scanner;

public class UncheckedExceptions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner (System.in);
		int arr[]=new int[5];
		try {
		System.out.println("enter the Array elemts");
		for(int j=0;j<arr.length;j++)
		{
			arr[j]=sc.nextInt();
		}
		
String s=null;
	System.out.println("Enter the index at which you want to search");
	int i=sc.nextInt();
	System.out.println("the element at given index is"+arr[i] );
	System.out.println("enter the element to divide with the array elements");
	int e=sc.nextInt();
	int d=arr[i]/e;
	System.out.println("the string is "+s);
	}
	catch(NullPointerException e)
	{
		System.out.println();
	}
		catch(ArithmeticException e)
		{
			System.out.println(e);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e);
		}
		catch(NumberFormatException e)
		{
			System.out.println(e);
		}
		 catch (InputMismatchException e) {
	            System.out.println("We have given input as float expecting integer "+ e);
}
	}
}
		
