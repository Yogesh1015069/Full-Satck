package testpackage;
import testpackage.foundation;
public class Another extends foundation{
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
foundation f=new foundation();
//System.out.println(f.var1);//var1 which is private shows an error 
System.out.println(f.var2);
System.out.println(f.var3);
System.out.println(f.var4);

	}

}
