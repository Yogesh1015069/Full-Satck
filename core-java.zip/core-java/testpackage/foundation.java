package testpackage;

public class foundation {
private int var1=1;
int var2=2;
protected int var3=3;
public int var4=4;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
