package FileStream;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ByteArrayStreamDemo {

	public static void main(String[] args) throws FileNotFoundException,IOException {
		// TODO Auto-generated method stub
		   FileOutputStream f1=new FileOutputStream("D:\\f1.txt");    
		      FileOutputStream f2=new FileOutputStream("D:\\f2.txt");    
		        
		      ByteArrayOutputStream bout=new ByteArrayOutputStream();    
		      bout.write(65);    
		      bout.writeTo(f1);    
		      bout.writeTo(f2);    
		        
		      bout.flush();    
		      bout.close();//has no effect    
	}

}
