package FileStream;

import java.io.FileOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.util.*;
public class BufferedOutputStreamDemo {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		try {
		  FileOutputStream fout=new FileOutputStream("C:\\Users\\yosah\\abc.txt");    
		     BufferedOutputStream bout=new BufferedOutputStream(fout);    
		     String s="Hello HIi Yash.";    
		     byte b[]=s.getBytes();   
		     
		     bout.write(b);    
		    		     bout.close();    
		     fout.close();    		
		     }
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
