package FileStream;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.IIOException;

public class countvowel {

	public static void main(String[] args)throws FileNotFoundException,IOException {
		// TODO Auto-generated method stub
		FileReader f=new FileReader("C:\\Users\\yosah\\combine.txt");
		BufferedReader br=new BufferedReader(f);
		int u=0,o=0,i=0,e=0,a=0;
		int vowel=0;
		   
        String currentLine = br.readLine();
         
        while (currentLine != null)
        {
           
            String[] words = currentLine.split(" ");
          
            for (String word : words)
            {
            	  System.out.println(word);
            	String s1=word;
            	for(int j=0;j<s1.length();j++)
            	{
            		char ch=s1.charAt(j);
            		if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='u')
            		{
            			vowel++;
            			if(ch=='a')
            			{
            				a++;
            			}
            			else if(ch=='e')
            			{
            				e++;
            			}
            			else if(ch=='i')
            			{
            				i++;
            			}
            			else if(ch=='o')
            			{
            				o++;
            			}
            			else {
            				u++;
            			}
            		}
            		
            	}
            	
            }
       
            currentLine = br.readLine();
        }
System.out.println("Vowels "+vowel+" a "+a+" e "+e+" i "+i+" o "+o+" u "+u);
        
	}

}
