package FileStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Employee implements Serializable{
	int EmpId;
	String empName;
	Employee(int EmpId,String empName)
	{
		this.EmpId=EmpId;
		this.empName=empName;
	}
	public String toString() {
		return EmpId +" "+empName;
	}
}
public class EmployObjectOutputStream {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
Employee e=new Employee(21,"Yogesh");
System.out.println(e);
File f=new File("C:\\Users\\yosah\\combine.txt");
//ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f)));

ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
oos.writeObject(e);
oos.close();

	}

}
