package FileStream;

import java.io.BufferedInputStream;
import java.io.FileInputStream;

public class BufferedInputDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		FileInputStream fi=new FileInputStream("C:\\Users\\yosah\\abc.txt");
BufferedInputStream bi=new BufferedInputStream(fi);
	int i;
	while((i=bi.read())!=-1)
	{
		System.out.println((char)i);
	}
	fi.close();
	bi.close();
	
		}
	catch(Exception e)
	{
		e.printStackTrace();
	}
		
		
	}

}
