package FileStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Scanner;

class Employees implements Serializable

{
	private String name;
	private String department;
	private String designation;
	private double salary;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public String toString() {
		return name +" "+department+" "+designation+" "+salary;
	}
	
	/*Employee(String name,String department,String designation,double salary){
		this.name=name;
		this.department=department;
		this.designation=designation;
		this.salary=salary;
	}*/
	
}
public class EmployeAssign {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String name,department,designation;
		double salary;
		System.out.println("Entyer your name");
		name=sc.next();
		System.out.println("enter your Designation");
		designation=sc.next();
		System.out.println("enter the department");
		department=sc.next();
		System.out.println("enter your Salary");
		salary=sc.nextDouble();
		
		Employees e=new Employees();
		e.setName(name);
		e.setDepartment(department);
		e.setDesignation(designation);
		e.setSalary(salary);
		System.out.println(e);
		System.out.println();
		System.out.println("File created");
		File f=new File("C:\\Users\\yosah\\yash.txt");
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
		
		File f1=new File("C:\\Users\\yosah\\yash.txt");
		ObjectInputStream oi=new ObjectInputStream(new FileInputStream(f1));
			Employees e1=(Employees)oi.readObject();
				System.out.println(e1);
				oi.close();
				
		//ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f)));
	}

}
