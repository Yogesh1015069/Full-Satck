package FileStream;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class DataOutputStreamDemo  {
	public static void main(String[] args) throws FileNotFoundException,IOException{
		  FileOutputStream file = new FileOutputStream("D:\\testout.txt");  
	        DataOutputStream data = new DataOutputStream(file);  
	        data.writeInt(65);  
	        data.flush();  
	        data.close();  
	        System.out.println("done");  
	        FileInputStream in = new FileInputStream("D:\\testout.txt");  
	        DataInputStream inst = new DataInputStream(in);  
	        int count = in.available();  
	        byte[] ary = new byte[count];  
	        inst.read(ary);  
	        for (byte bt : ary) {  
	          char k = (char) bt;  
	          System.out.print(k+"-");  
	        }  
	}
}
