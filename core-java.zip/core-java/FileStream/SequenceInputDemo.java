package FileStream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.SequenceInputStream;

public class SequenceInputDemo {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		FileInputStream f1=new FileInputStream("C:\\Users\\yosah\\abc.txt");
		FileInputStream f2=new FileInputStream("C:\\Users\\yosah\\xyz.txt");
		FileOutputStream f3=new FileOutputStream("C:\\Users\\yosah\\combine.txt");
		SequenceInputStream st=new SequenceInputStream(f1,f2);
		
		
		int i;
		while((i=st.read())!=-1)
		{
			f3.write((char)i);
			System.out.print((char)i);
		}
		f1.close();
		f2.close();
		f3.close();
		System.out.println();
		FileInputStream f=new FileInputStream("C:\\Users\\yosah\\combine.txt");
		int j;
		while((j=f.read())!=-1)
		{
		
			System.out.print((char)j);
		}
		f.close();
	}

}
