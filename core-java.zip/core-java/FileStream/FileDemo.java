package FileStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream in=null;
		FileOutputStream op=null;
		try {
			in = new FileInputStream("C:\\\\Users\\\\yosah\\\\abc.txt");
			//op = new FileOutputStream("C:\\Users\\yosah\\xyz.txt");
			op=new FileOutputStream("C:\\Users\\yosah\\xyz.txt",true);
					//append karne k liy 
			int c;
			while((c=in.read())!=-1)//=yash -1 last m ayega
			{
			//	op.write(c);
				System.out.println((char)(c));
			}
		} catch (FileNotFoundException   e1) {
			e1.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		
	

finally
{
	try {
		if(in!=null&&op!=null)
		{
		in.close();
		op.close();
		}
		
	} catch (IOException e) {
		e.printStackTrace();
	}
	
	
}
	}
}
