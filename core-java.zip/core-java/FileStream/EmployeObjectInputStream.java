package FileStream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
class Employee implements Serializable{
	int EmpId;
	String empName;
	Employee(int EmpId,String empName)
	{
		this.EmpId=EmpId;
		this.empName=empName;
	}
	public String toString() {
		return EmpId +" "+empName;
	}
}
public class EmployeObjectInputStream {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		File f=new File("C:\\Users\\yosah\\combine.txt");
ObjectInputStream oi=new ObjectInputStream(new FileInputStream(f));
	Employee e=(Employee)oi.readObject();
		oi.close();
		System.out.println(e);
	}

}
