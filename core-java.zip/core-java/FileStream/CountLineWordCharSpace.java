package FileStream;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CountLineWordCharSpace {

	public static void main(String[] args) throws FileNotFoundException,IOException{
		// TODO Auto-generated method stub
		FileReader f=new FileReader("C:\\Users\\yosah\\combine.txt");
		BufferedReader br=new BufferedReader(f);
		int line=0,character=0,space=0,wo=0;
		String s;
		   
        String currentLine = br.readLine();
         
        while (currentLine != null)
        {
            line++;
            String[] words = currentLine.split(" ");
            space+=words.length;
            wo = wo + words.length;
          
            for (String word : words)
            {
            	System.out.println(word);
                character = character + word.length();
            }
       
            currentLine = br.readLine();
        }
System.out.println("line "+line+" words "+wo+" character "+character+" Space"+space);
        
	}

}
