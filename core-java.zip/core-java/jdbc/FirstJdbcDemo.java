package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class FirstJdbcDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url ="jdbc:mysql://localhost:3306/jaynam";
			String user="root";
			String pass ="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created successfully");
			}
			{
				System.out.println("Connection is not Created");
			}
			String q="select * from employee";
			Statement st= con.createStatement();
			ResultSet set=st.executeQuery(q);
			while(set.next())
			{
				int id=set.getInt("empID");
				String name=set.getString("name");
				System.out.println("id:"+id);
				System.out.println("name"+name);
			}
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
