package Reflection;
class A{
	
}
public class DemoForMe {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class c=Class.forName("A");
		System.out.println(c.getName());
	}

}
