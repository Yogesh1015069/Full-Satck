package Reflection;

public class IsArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Class<int[]> c = int[].class;
        System.out.println(c.isArray());
        boolean b = int.class.isPrimitive();
        System.out.println(b);

        b = int[].class.isPrimitive();
        System.out.println(b);

        b = Integer.class.isPrimitive();
        System.out.println(b);
	}

}
