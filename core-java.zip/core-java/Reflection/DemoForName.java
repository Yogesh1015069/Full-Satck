package Reflection;
class A{}
public class DemoForName {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
Class c=Class.forName("A");
System.out.println(c.getName());//how to get the object of Class(java.lang) class?*/
System.out.println(c.isInterface());
Class cl=Class.forName("b");
System.out.println(cl.isInterface());
	}
/*  Determing the class Obk=jrct (Reflection API is used to determine the object type)
 *    bolean isInterface():-Specified class object represtation interface type or not
 * 	 bolean IsArray():-class object represents an Array
 * boolean isPrimitive():-class object represent primitive
 * Classs getSuperClass()-->returns the superclass refrence
 * getDeclaredFields()
 * getDecaredMethod()
 * getDeclaredMethods()
 */
}
