package Reflection;
class A{}
public class DemoGetClass {
	void show(Object o)
	{
		Class c=o.getClass();
		System.out.println(c.getName());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a=new A();
		DemoGetClass d=new DemoGetClass();
		d.show(a);
	}

}
