package student.java;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Operations {
	static String url ="jdbc:mysql://localhost:3306/apache";
	static String users="root";
	static String passwrd ="root";
	static Connection con;
static void insert() throws SQLException
{
	con=DriverManager.getConnection(url,users,passwrd);
	PreparedStatement st= con.prepareStatement("INSERT into student values(?,?)");
	st.setInt(1, 1);
	st.setString(2, "yogesh");
	int x=st.executeUpdate();
	System.out.println(x+"result insteted");
}
static void view () throws SQLException
{
	con=DriverManager.getConnection(url,users,passwrd);
	Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
	String q="select * from student";
	ResultSet x=st.executeQuery(q);
	while(x.next())
	{
		int a=x.getInt("id");
		String b=x.getString("name");
		System.out.println("Studemt id "+a+" name is "+b);
	}
	System.out.println(x+"result insteted");
}
static void delete () throws SQLException
{
	con=DriverManager.getConnection(url,users,passwrd);
	PreparedStatement st= con.prepareStatement("delete * from student where id =(?)");
	st.setInt(1,123);
	int x=st.executeUpdate();
	System.out.println(x+"result delete");
}
}
