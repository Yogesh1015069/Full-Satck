package student.java;

import java.sql.SQLException;

public class main extends Operations {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
insert();
view();

	}

}
