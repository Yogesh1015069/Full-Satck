

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Pattern;



public class LibaryMangementSystem extends user {
	
	static String url ="jdbc:mysql://localhost:3306/Library";
	static String users="root";
	static String passwrd ="root";
	static Connection con;
	static ArrayList <Object> b=new ArrayList<>();
	static ArrayList<Object> stud=new ArrayList<>();
	private static void searchBook() throws IOException {
		// TODO Auto-generated method stub
		 	InputStreamReader r=new InputStreamReader(System.in);    
		    BufferedReader br=new BufferedReader(r);            
		    System.out.println("Enter the book name");
		    String name=br.readLine(); 
		    try {
		    	String q="SELECT *FROM book";
				con=DriverManager.getConnection(url,users,passwrd);
				Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				ResultSet set=st.executeQuery(q);
				while(set.next())
					{
					
					String bookname=set.getString("bookname");
					if(name.equals(bookname)) {
						int id=set.getInt("bookid");
						System.out.print("Book id:"+id);
						System.out.print(" Book name  "+bookname);
						System.out.println(" Book Found");
						System.out.println();
					}
					else {
						System.out.println("Book Not found");
					}
					}
			} catch (SQLException e) {
				e.printStackTrace();
			}			
		    
		
	}
	private static void adminMenu() throws IOException, ParseException, InputMismatchException, NumberFormatException, SQLException  {
		System.out.println("------------Welcome admin----------------");
		System.out.println("1.Add Books");
		System.out.println("2.View Issued Books");
		System.out.println("3.All Books in Library");
		System.out.println("4.Search Book");
		System.out.println("5.Main Menu");
		System.out.println("6.Register Student ");
		System.out.println("7.Exit");
		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		do {
			switch(choice)
			{
			case 1:
				addBook();
				adminMenu();
				break;
			case 2:
				user.allissue();
				adminMenu();
				break;
			case 3:
				allBooks();
				adminMenu();
				break;
			case 4:
				searchBook();
				adminMenu();
				break;
			case 5:
				mainMenu();
				break;
			case 6:
				studentlogin.addStudent();
				adminMenu();
			case 7:
				System.exit(0);
				break;
		 default:
				System.out.println("-------Invalid Input------");
				
			}
			
		} while(choice >0 &&choice<8);
	}
	
	private static  void userMenu() throws IOException, ParseException,InputMismatchException, NumberFormatException, SQLException
	{
		System.out.println("-----------Welcome User------------");
		
		System.out.println("1.To issue a book");
		System.out.println("2.To return a book");
		System.out.println("3.To print the book details");
		System.out.println("4.All Books in Libary");
		System.out.println("5.To go Main Menu");
		System.out.println("6.To exit");
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		do {
			switch (choice) {
			case 1:
				issueBook();
				userMenu();
				break;
			case 2:
				returnBook();
				userMenu();
				break;
			case 3:
				printBookDetails();
				userMenu();
				break;
			case 4:
				allBooks();
				userMenu();
				break;
			case 5:
				mainMenu();
				break;
			case 6:
				System.exit(0);
				break;	
			default:
				System.out.println("Invalid input");
				break;
			}
			
			choice = sc.nextInt();
		} while (choice > 0 && choice < 7);
	}
	private static void printBookDetails() throws NumberFormatException, IOException ,InputMismatchException, SQLException{
		// TODO Auto-generated method stub
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b1=new BufferedReader(i);
		System.out.println("Enter the Book id");
		int bookId = Integer.parseInt(b1.readLine());
		con=DriverManager.getConnection(url,users,passwrd);
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		ResultSet set=st.executeQuery("select * from book");
		boolean re=false;
		while(set.next())
			{
			int id=set.getInt("bookid");
			if(id==bookId)
			{
			String bookname=set.getString("bookname");
			System.out.print("Book id:"+id);
			System.out.print(" Book name  "+bookname);
			System.out.println("Book Price "+set.getDouble("price"));
			System.out.println();
			re=true;
			break;
			}
			if(re==false)
			{
				System.out.println("not found");
			}
			
			}
		
	}




	public static void mainMenu() throws IOException, ParseException,InputMismatchException, NumberFormatException, SQLException
	{
		System.out.println("Library Management System");
		System.out.println("1.Admin Login");
		System.out.println("2.User Login");
		System.out.println("3.Exit");

		Scanner sc=new Scanner(System.in);
		int choice=sc.nextInt();
		do {
			switch(choice)
			{
			case 1:
				checkLogIn();
				
				break;
			case 2: 
				stud.add(new studentlogin(123,"Yogesh"));
				stud.add(new studentlogin(321,"Piyush"));
				checkStudent();
				userMenu();
			case 3:
				System.exit(0);
				break;
				default:
					System.out.println("Ivalid Input");
					break;
			}
		}
		while(choice>0&&choice<4);
	}
	
	private static void checkLogIn() throws IOException, ParseException,InputMismatchException, NumberFormatException, SQLException {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the admin name");
		String usrname=sc.next();
		System.out.println("Enter the password");
		String passwrd=sc.next();
		if(Pattern.matches("[a-zA-Z0-9]{8}", passwrd)) {
		
		if((usrname.equals("admin"))&& passwrd.equals("admin123"))
		{
			System.out.println("Log in Sucees full");
			adminMenu();
		}
		else {
			System.out.println("Invalid Password");
			mainMenu();
		}
		}
		else
		{
			System.out.println("Password MisMatch");
		}
	}
	private static void checkStudent() throws IOException, ParseException,InputMismatchException, NumberFormatException, SQLException {
InputStreamReader s=new InputStreamReader(System.in);
BufferedReader b= new BufferedReader(s);
System.out.println("Enter your Student id");
int r=Integer.parseInt(b.readLine());
System.out.println("enter your name");
String name=b.readLine();

	
if(studentlogin.checkloginStudent(r,name))
{
	System.out.println("Login Succesful");
	userMenu();
}
else {
	System.out.println("Login Invalid Kindly Register");
	System.out.println("--------------------------------");
	mainMenu();
}

		}
	
	static void addBook() throws NumberFormatException, IOException,InputMismatchException{
		InputStreamReader s=new InputStreamReader(System.in);
		BufferedReader bf= new BufferedReader(s);
		System.out.println("enter the Book Number");
		int number=Integer.parseInt(bf.readLine());
		System.out.println("enter the Book name");
		String name=bf.readLine();
		System.out.println("enter the Book price ");
		double price=Double.parseDouble(bf.readLine());
		 try {
		    	
				con=DriverManager.getConnection(url,users,passwrd);
				PreparedStatement st= con.prepareStatement("INSERT into book values(?,?,?)");
				st.setInt(1, number);
				st.setString(2, name);
				st.setDouble(3, price);
				int x=st.executeUpdate();
				System.out.println(x+"result insteted");
			} catch (SQLException e) {
				e.printStackTrace();
			}			
			System.out.println("Book add Succesfully");
		
		//	System.out.println("Error in Adding Book");
		
	}
	static void allBooks() throws InputMismatchException
	{

			String q="select * from book";
			
			try {
				con=DriverManager.getConnection(url,users,passwrd);
				Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				ResultSet set=st.executeQuery(q);
				while(set.next())
					{
					int id=set.getInt("bookid");
					String bookname=set.getString("bookname");
					//String issuedate=set.getString("issuedate");
					System.out.print("Book id:"+id);
					System.out.print(" Book name  "+bookname);
					System.out.println("Book Price "+set.getDouble("price"));
					//System.out.print(" Issued on "+issuedate);
					System.out.println();
					}
			} catch (SQLException e) {
				e.printStackTrace();
			}			
			
			
	
	}
	static void viewIssuedBooks() throws InputMismatchException{
		
		String q="select * from issuedbook";
		
		try {
			con=DriverManager.getConnection(url,users,passwrd);
			Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet set=st.executeQuery(q);
			while(set.next())
				{
				int id=set.getInt("bookid");
				String bookname=set.getString("bookname");
				//String issuedate=set.getString("issuedate");
				System.out.print("Book id:"+id);
				System.out.print(" Book name  "+bookname);
				System.out.println(" Issued Date "+set.getDate("issuedate"));
				System.out.println("Book Price "+set.getDouble("price"));
				//System.out.print(" Issued on "+issuedate);
				System.out.println();
				}
		} catch (SQLException e) {
			e.printStackTrace();
		}			
	}
	
	public static void main(String[] args) throws IOException, ParseException, InputMismatchException, NumberFormatException, SQLException {
			mainMenu();
		
	}
	

	
}

