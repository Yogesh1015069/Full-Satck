
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

class studentlogin {
	int Studentid;
	String Studentname;
	static HashMap<Integer,String> map=new HashMap<Integer,String>();
	static boolean checkloginStudent(int r,String name){
		Set<Entry<Integer, String>> s=map.entrySet();
		
		Iterator<Entry<Integer,String>> i=s.iterator();
		while(i.hasNext())
		{
			Map.Entry entry=(Map.Entry)i.next();
			if((entry.getKey().equals(r))&&(entry.getValue().equals(name)))
			{
				return true;
			}
		}
		
		return false;
		
	}
	studentlogin(int Studentid,String name)
	{
		super();
		map.put(Studentid,name);
		this.Studentid=Studentid;
		this.Studentname=name;
	}
	static void addStudent() throws NumberFormatException, IOException
	{
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b=new BufferedReader(i);
		System.out.println("Enter the Id to assign");
		int id=Integer.parseInt(b.readLine());
		System.out.println("Enter the name to register");
		String name=b.readLine();
		map.put(id,name);
		System.out.println("Student Registered");
	}
	public String toString() {
		return "Student id "+Studentid+"Student Name "+Studentname;
		
	}
}
public class user {
	static String url ="jdbc:mysql://localhost:3306/Library";
	static String users="root";
	static String passwrd ="root";
	static Connection con;
static void allissue() {
	String q="select * from issuedbook";
	
	try {
		con=DriverManager.getConnection(url,users,passwrd);
		Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		ResultSet set=st.executeQuery(q);
		while(set.next())
			{
			int id=set.getInt("bookid");
			String bookname=set.getString("bookname");
			//String issuedate=set.getString("issuedate");
			System.out.print("Book id:"+id);
			System.out.print(" Book name  "+bookname);
			System.out.println(" Issued Date "+set.getDate("issuedate"));
			System.out.println("Book Price "+set.getDouble("price"));
			//System.out.print(" Issued on "+issuedate);
			System.out.println();
			}
	} catch (SQLException e) {
		e.printStackTrace();
	}			
	}
	
	public static void returnBook() throws NumberFormatException, IOException {
		System.out.println("Enter studentId ");
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b1=new BufferedReader(i);
		int id = Integer.parseInt(b1.readLine());
		System.out.println("Enter the Book id");
		int number = Integer.parseInt(b1.readLine());
		 System.out.println();
		 try {
		    	String q="SELECT *FROM issuedbook";
		    	
				con=DriverManager.getConnection(url,users,passwrd);
				Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
				ResultSet set=st.executeQuery(q);
				
				while(set.next())
					{
				
					
					int  bookid=set.getInt("bookid");
					double price=set.getDouble("price");
					if(bookid==number) {
						Statement st2 = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
						PreparedStatement pst= con.prepareStatement("set @daystotal=(select datediff(curdate(),issuedate) from issuedbook where bookid=?)");
				pst.setInt(1,number);
						pst.executeUpdate();
						String s1="insert into days values(@daystotal)";
						
						st2.addBatch(s1);
						st2.executeBatch();
						ResultSet rs= st2.executeQuery("select * from days");
						int w=0;
					while(rs.next())
						{
							 w=rs.getInt("day");
							System.out.println(w);
							break;
						}
					
					if(w>30)
					{
						int exceday = w - 30;
						double fine = exceday*price;
						close();
						System.out.println("Total Price to pay " + fine + " Rs.");
						System.exit(0);
					}
					else {
						System.out.println("No need to pay any Fine Thank You");
					}
						
						break;
					}
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}			
		
		

	}
	

	private static void close() throws SQLException {
		// TODO Auto-generated method stub
		con=DriverManager.getConnection(url,users,passwrd);
		Statement st2 = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		st2.executeQuery("delete from days");
	}

	protected static void issueBook() throws IOException, ParseException, SQLException {
		InputStreamReader i=new InputStreamReader(System.in);
		BufferedReader b1=new BufferedReader(i);
		System.out.println("Enter Booknumber, name  date and price");
		System.out.println("enter Book Number");
		int bookNumber = Integer.parseInt(b1.readLine());
		System.out.println("enter Book Name");
		String name = b1.readLine();
		con=DriverManager.getConnection(url,users,passwrd);
		Statement st2 = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		ResultSet set=st2.executeQuery("select * from book");
		boolean re=false;
		while(set.next())
			{
			int id=set.getInt("bookid");
			if(id==bookNumber)
			{
				System.out.println("enter price");
				double price=Double.parseDouble(b1.readLine());
				System.out.println("enter date in yyyy-mm-dd format");
				String issueDate = b1.readLine();
				Date issueddate=Date.valueOf(issueDate);
				 try {
				    	
						con=DriverManager.getConnection(url,users,passwrd);
						PreparedStatement st= con.prepareStatement("INSERT into issuedbook values(?,?,?,?)");
						st.setInt(1, bookNumber);
						st.setString(2, name);
						st.setDate(3, issueddate);
						st.setDouble(4, price);
						int x=st.executeUpdate();
						System.out.println(x+"result insteted");
					} catch (SQLException e) {
						e.printStackTrace();
					}			
			System.out.println("add succesfully");
			}
			}
		
	}
	
	
	
}
