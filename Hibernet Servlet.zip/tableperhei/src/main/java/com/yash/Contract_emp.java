package com.yash;
	import javax.persistence.Column;  
	import javax.persistence.DiscriminatorValue;  
	import javax.persistence.Entity;  
	  
	@Entity  
	@DiscriminatorValue("contractemployee")  
	public class Contract_emp extends Employee{  
	      
	    @Column(name="pay_hour")  
	    private float pay_hour;  
	  
		@Column(name="contract_period")  
	    private String contract_period;

		public float getPay_hour() {
			return pay_hour;
		}

		public void setPay_hour(float pay_hour) {
			this.pay_hour = pay_hour;
		}

		public String getContract_period() {
			return contract_period;
		}

		public void setContract_period(String contract_period) {
			this.contract_period = contract_period;
		} 
}
