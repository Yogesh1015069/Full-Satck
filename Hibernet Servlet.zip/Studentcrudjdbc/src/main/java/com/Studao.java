package com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Studao {

	  protected static Connection getConnection() {
		   
	        Connection connection = null;
	        try {
	        	String connectionURL = "jdbc:mysql://localhost:3306/apache";
	        	
	        	Class.forName("com.mysql.jdbc.Driver");
	        	connection = DriverManager.getConnection(connectionURL, "root", "root");   
	        
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } catch (ClassNotFoundException e) {
	            e.printStackTrace();
	        }
	        return connection;
	    }
	  static int  insert(Student s) throws SQLException
	  {
		 Connection c=getConnection();
		 PreparedStatement pst=c.prepareStatement("insert into student values(?,?)");
		 pst.setInt(1,s.getId());
		 pst.setString(2,s.getName());
		int r= pst.executeUpdate();
		  return r;
	  }
	  
}
