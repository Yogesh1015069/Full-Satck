package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/add")
public class add extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int id=Integer. parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		Student s=new Student(id, name);
		try {
			int status=Studao.insert(s);
			if (status > 0) {
				out.print("<marquee>Record saved successfully!</marquee>");
				request.getRequestDispatcher("index.html").include(request, response);
			} else {
				out.println("Sorry! unable to save record");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		out.close();
	}

}
