package com.yash;


import org.hibernate.*;  
import org.hibernate.boot.Metadata;  
import org.hibernate.boot.MetadataSources;  
import org.hibernate.boot.registry.StandardServiceRegistry;  
//import org.hibernate.boot.registry.StandardServiceRegistryBuildee;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;    
    
public class Store {
	public static void main(String[] args) {    
	      
	    StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();  
	    Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();  
	      
	    SessionFactory factory=meta.getSessionFactoryBuilder().build();  
	    Session session=factory.openSession();  
	      
	    Transaction t=session.beginTransaction();   
	      
	    Employee e1=new Employee();    
	    e1.setFname("Yogesh");    
	    e1.setLname("sahu");
	    e1.setSalary(420000);
	    Address address1=new Address();    
	        address1.setCity_name("raigrah");
	        address1.setState_name("Chhattisarh");
	        address1.setStreet_name("kudumkela");
	        address1.setZipcode("496111");
	        
	    e1.setAddress(address1);    
	    address1.setEmployee(e1);    
	        
	    session.persist(e1);    
	    t.commit();    
	        
	    session.close();    
	    System.out.println("success");    
	}    
}

