

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=res.getWriter();
		String Fname=req.getParameter("Fname");
		String Lname=req.getParameter("Lname");
		String password=req.getParameter("passwrd");
		String cnfpassword=req.getParameter("cnfpasswrd");
		String Email=req.getParameter("email");
		String  Gender=req.getParameter("gen");
		String Income=req.getParameter("income");
		String Bio=req.getParameter("bio");
		if(password.equals(cnfpassword))
		{
			out.println("welcome to page ");
			out.println(Fname);
			out.println(Lname);
			out.println(Email);
			out.println(Gender);
			out.println(Income);
			out.println(Bio);
			
		}
		else
		{
			out.print("error");
		}
		
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, res);
	}

}
