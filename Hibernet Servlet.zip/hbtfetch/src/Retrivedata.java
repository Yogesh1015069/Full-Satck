import java.util.List; 
import java.util.Date;
import java.util.Iterator; 
 
import org.hibernate.HibernateException; 
import org.hibernate.Session; 
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.SessionFactory;
public class Retrivedata {

	public static void main(String[] args) {
	
		// TODO Auto-generated method stub
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");
     SessionFactory factory = cfg.buildSessionFactory(); 
		 Session session = factory.openSession(); 
	     
	      
	      try {
	 
	         List li = session.createQuery("from employee e").list(); 
	         Iterator iterator = li.iterator(); 
	         while(iterator.hasNext()){
	        	 Object obj=(Object)iterator.next();
	            Employee employee = (Employee)obj; 
	            System.out.print("First Name: " + employee.getFirstName()); 
	            System.out.print("  Last Name: " + employee.getLastName()); 
	            System.out.println("  Salary: " + employee.getSalary()); 
	         }
	         session.close();
	         factory.close();
	         
	      } catch (HibernateException e) {
	         
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
		
	}

}
