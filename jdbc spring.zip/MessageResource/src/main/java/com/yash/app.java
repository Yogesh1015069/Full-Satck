package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class app {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ApplicationContext context=new ClassPathXmlApplicationContext("appcontext.xml");  
		  System.out.println( context.getMessage("greeting",null,"default message",null));
		    ((AbstractApplicationContext) context).close();
	}

}
