package com.yash.Springorm;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.dao.StudentDao;
import com.yash.entities.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println( "Hello World!" );
    	ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
    	StudentDao studao=context.getBean("studentDao",StudentDao.class);
    	//Student stu=new Student(23,"Bittu");
    	//int msg=studao.insert(stu);
    	//System.out.println(msg + "insertion done");
    	Student stu1=new Student(23,"yogesh");
    	studao.updateDetails(stu1);
    	
List<Student> students = studao.getAllStudents();
        
        for (Student record : students) {
           System.out.print("ID : " + record.getId() );
           System.out.print(", Name : " + record.getName() );
           System.out.println();
        }
       studao.deleteDetails(123);
    	
    	}
    }

