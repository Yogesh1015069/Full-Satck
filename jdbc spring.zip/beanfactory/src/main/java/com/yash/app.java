package com.yash;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.yash.Student;

public class app {
	public static void main(String []args) {
	System.out.println("Welcome to first Applications");
	Resource resource=new ClassPathResource("appcontext.xml");
	BeanFactory factory =new XmlBeanFactory(resource);
	Student e = (Student) factory.getBean("stud");
	System.out.println(e);
	Student e1 = (Student) factory.getBean("stud1");
	System.out.println(e1);
	Student e2 = (Student) factory.getBean("stud2");
	System.out.println(e2);
}
}