package com.yash;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class app {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("appcontext.xml");
		Hello obj = (Hello) context.getBean("helloWorld");
		obj.getMessage();
		context.registerShutdownHook();
	}
}
