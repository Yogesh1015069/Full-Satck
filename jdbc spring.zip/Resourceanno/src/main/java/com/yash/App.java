package com.yash;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
public class App {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ApplicationContext ac = new ClassPathXmlApplicationContext("appcontext.xml");
	        Employee emp = ac.getBean("myemployee", Employee.class);
	        System.out.println(emp.toString());
	}

}
