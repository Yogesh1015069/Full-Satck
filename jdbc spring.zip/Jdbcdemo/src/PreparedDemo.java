import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class PreparedDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		String url ="jdbc:mysql://localhost:3306/apache";
		String user="root";
		String pass ="root";
		Connection con=DriverManager.getConnection(url,user,pass);
		if(con!=null)
		{
		System.out.println("Connection is created successfully");
		String q="select * from persons";
		Statement smt= con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		PreparedStatement st= con.prepareStatement("INSERT into persons values(?,?,?,?,?)");
		st.setInt(1,432);
		st.setString(2,"sameer");
		st.setString(3,"ekka");
		st.setString(4,"nwadhi");
		st.setString(5,"raigarh");
		
		int i=st.executeUpdate();
		System.out.println(i+"result insteted");
		ResultSet set=smt.executeQuery(q);
		set.absolute(3);
		System.out.println(set.getInt(1)+" "+set.getString(2)+" "+set.getString(3)+" "+set.getString(4)+" "+set.getString(5));
		}
		else{
		System.out.println("Connection is not Created");
		}
		con.close();
		}
		catch(Exception e)
		{
		System.out.println(e);
		}
				
	}

}
