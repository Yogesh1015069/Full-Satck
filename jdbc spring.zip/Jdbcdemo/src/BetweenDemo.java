import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class BetweenDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String url ="jdbc:mysql://localhost:3306/apache";
			String user="root";
			String pass ="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
			System.out.println("Connection is created successfully");
			String q="select distinct * from persons where PersonID between 100 and 300;";
			Statement smt= con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			ResultSet set=smt.executeQuery(q);
			while(set.next())
			{
				System.out.print("id:"+set.getInt("PersonID"));
				System.out.print(" name  "+set.getString("FirstName"));
				System.out.print(" "+set.getString("LastName"));
				System.out.println();
			}
			}
			else{
			System.out.println("Connection is not Created");
			}
			con.close();
			}
			catch(Exception e)
			{
			System.out.println(e);
			}
	}

}
