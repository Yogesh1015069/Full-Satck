import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class jdbcfirst {

	public static void main(String[] args) {
		
		try
		{
			//Class.forName("com.mysql.jdbc.Driver");
			String url ="jdbc:mysql://localhost:3306/apache";
			String user="root";
			String pass ="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
			System.out.println("Connection is created successfully");
			String q="select * from persons";
			Statement st= con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			
			ResultSet set=st.executeQuery(q);
			ResultSetMetaData rsmd=set.getMetaData();
			System.out.println("Total columns: "+rsmd.getColumnCount());  
			System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));  
			System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1)); 
			set.absolute(1);  
			
			System.out.println(set.getInt(1)+" "+set.getString(2)+" "+set.getString(3)+" "+set.getString(4)+" "+set.getString(5));  
			while(set.next())
			{
			int id=set.getInt("PersonID");
			String lastname=set.getString("Lastname");
			String name=set.getString("Firstname");
			
			System.out.print("id:"+id);
			System.out.print(" name  "+name);
			System.out.print(" "+lastname);
			System.out.println();
			}
		
			}
			else{
			System.out.println("Connection is not Created");
			}
			con.close();
			}
			catch(Exception e)
			{
			System.out.println(e);
			}
					
		
		
		
	}

}
