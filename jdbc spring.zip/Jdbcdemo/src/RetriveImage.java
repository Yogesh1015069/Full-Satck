import java.io.FileOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class RetriveImage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String url ="jdbc:mysql://localhost:3306/apache";
			String user="root";
			String pass ="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
			System.out.println("Connection is created successfully");
		PreparedStatement ps=con.prepareStatement("select * from image");  
		ResultSet rs=ps.executeQuery();  
		if(rs.next()){//now on 1st row    
		Blob b=rs.getBlob(2);//2 means 2nd column data  
		byte barr[]=b.getBytes(1,(int)b.length());//1 means first image  
		FileOutputStream fout=new FileOutputStream("d:\\Dog_breed_retrive_image.jpg");  
		fout.write(barr); 
		System.out.println("retrived");
		fout.close(); 
		}}
		else{
			System.out.println("Connection is not Created");
			}
			con.close();
			}
			catch(Exception e)
			{
			System.out.println(e);
			}
			
	}

}
