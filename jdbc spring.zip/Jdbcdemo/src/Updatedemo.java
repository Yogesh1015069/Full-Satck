import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class Updatedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String url ="jdbc:mysql://localhost:3306/apache";
			String user="root";
			String pass ="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
			System.out.println("Connection is created successfully");
			String q="select * from persons";
			Statement smt= con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
			PreparedStatement st= con.prepareStatement("UPDATE persons set Firstname =?  where PersonID=? ");
			InputStreamReader i1=new InputStreamReader(System.in);
			BufferedReader b=new BufferedReader(i1);
			System.out.println("enter the id");
			
			st.setInt(1,Integer.parseInt(b.readLine()));
			System.out.println("enter the name");
			st.setString(2,b.readLine());

			int i=st.executeUpdate();
			System.out.println(i+"result updated");
			ResultSet set=smt.executeQuery(q);
			set.absolute(4);
			System.out.println(set.getInt(1)+" "+set.getString(2)+" "+set.getString(3)+" "+set.getString(4)+" "+set.getString(5));
			}
			else{
			System.out.println("Connection is not Created");
			}
			con.close();
			}
			catch(Exception e)
			{
			System.out.println(e);
			}
	}

}
