import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertImage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			String url ="jdbc:mysql://localhost:3306/apache";
			String user="root";
			String pass ="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
			System.out.println("Connection is created successfully");
			String q="select * from persons";
			Statement smt= con.createStatement();
			PreparedStatement st= con.prepareStatement("INSERT into image values(?,?)");
			st.setInt(1,432);
			FileInputStream f=new FileInputStream("d:\\Dog_Breeds.jpg");
			st.setBinaryStream(2,f,f.available());
		
			int i=st.executeUpdate();
			System.out.println(i+"result insteted");
			
			}
			else{
			System.out.println("Connection is not Created");
			}
			con.close();
			}
			catch(Exception e)
			{
			System.out.println(e);
			}

	}

}
