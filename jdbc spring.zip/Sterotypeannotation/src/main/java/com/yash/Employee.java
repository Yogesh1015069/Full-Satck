package com.yash;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("ob")
@Scope("prototype")
public class Employee {
@Value("Yogesh")
private String empName;
@Value("Raigarh")
private String location;
public String getEmpName() {
return empName;
}
public String getLocation() {
return location;
}
public void setEmpName(String empName) {
this.empName = empName;
}
public void setLocation(String location) {
this.location = location;
}
@Override
public String toString() {
return "Employee [empName=" + empName + ", location=" + location + "]";
}


}
