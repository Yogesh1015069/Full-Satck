package com.yash;
import java.util.Iterator;  
import java.util.List;  
public class Lis1 {
public List<String>teams;

public List <String>getTeams() {
	return teams;
}

public void setTeams(List<String> teams) {
	this.teams = teams;
}
public void displayInfo() {
	 Iterator itr=teams.iterator();  
	    while(itr.hasNext()){  
	        System.out.println(itr.next());  
	    }  
}
}
