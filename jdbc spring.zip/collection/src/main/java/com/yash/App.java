package com.yash;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		
		System.out.println("Welcome to first Applications");
		ApplicationContext context = new ClassPathXmlApplicationContext("appcontext.xml");
		Lis1 e = (Lis1) context.getBean("lista");
		e.displayInfo();
	}
}
