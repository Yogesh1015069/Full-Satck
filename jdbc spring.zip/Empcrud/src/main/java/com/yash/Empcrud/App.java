package com.yash.Empcrud;

import java.sql.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.dao.EmployeeDao;
import com.yash.entites.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println( "Hello World!" );
    	ApplicationContext context=new ClassPathXmlApplicationContext("appcontext.xml");
    	EmployeeDao emdao=context.getBean("EmployeeDao",EmployeeDao.class);

    	Employee e=new Employee();
    	e.setEmpname("yogesh");
    	e.setEmail("yosahu22@gmail.com");
    	//e.setDob("09/12/2000");
    	e.setContactno(982922087);
    	e.setSalary(42000);
    	int r=emdao.insert(e);
    	//s.setId(108);
    	//s.setName("piyush dubey");
    	//int r=stdao.insert(s);//insert 
    	//int r=stdao.updatedetails(s);
    	System.out.println(r + "Student added Successfully ");
    	//int r=stdao.deletedetails(105);//delete the details
    	//System.out.println(r + "Student deleted Successfully ");
    }
}
