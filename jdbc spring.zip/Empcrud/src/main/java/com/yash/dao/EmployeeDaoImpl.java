package com.yash.dao;

import org.springframework.jdbc.core.JdbcTemplate;

import com.yash.entites.Employee;

public class EmployeeDaoImpl {
	private JdbcTemplate jdbctemp;

	public int insert(Employee emp) {

		String q = "insert into employee(empname,email,dob,contatctno,salary) values(?,?,?,?,?)";
		int msg = this.jdbctemp.update(q, emp.getEmpname(), emp.getEmail(),emp.getDob(),emp.getContactno(),emp.getSalary());
		return msg;
	}
	public int updatedetails(Employee emp) {
		// update details of student
		String q="update employee set salary=? where empname=?";
		int msg=this.jdbctemp.update(q,emp.getSalary(),emp.getEmpname());

		return msg;
		}
	public int deletedetails(String empname ) {
		// TODO Auto-generated method stub
		String q="delete from employee where empname=?";
		int msg=this.jdbctemp.update(q,empname);
		return msg;
		}

	public JdbcTemplate getJdbctemp() {
		return jdbctemp;
	}

	public void setJdbctemp(JdbcTemplate jdbctemp) {
		this.jdbctemp = jdbctemp;
	}
}
