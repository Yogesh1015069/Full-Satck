package com.yash.dao;

import com.yash.entites.Employee;
 public interface EmployeeDao {
	public int insert(Employee emp);
	public int updatedetails(Employee emp);
	public int deletedetails(String empname);
}
