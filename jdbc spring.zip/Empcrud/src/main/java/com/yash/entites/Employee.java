package com.yash.entites;

import java.math.BigInteger;
import java.sql.Date;

public class Employee {
public String empname;
public String email;
public String dob;
public long contactno;
public int salary;
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
public Employee(String empname, String email, Date dob, long contactno, int salary) {
	super();
	this.empname = empname;
	this.email = email;
	this.dob = dob;
	this.contactno = contactno;
	this.salary = salary;
}
public String getEmpname() {
	return empname;
}
public void setEmpname(String empname) {
	this.empname = empname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public long getContactno() {
	return contactno;
}
public void setContactno(long contactno) {
	this.contactno = contactno;
}
public int getSalary() {
	return salary;
}
public void setSalary(int salary) {
	this.salary = salary;
}
@Override
public String toString() {
	return "Emloyee [empname=" + empname + ", email=" + email + ", dob=" + dob + ", contactno=" + contactno
			+ ", salary=" + salary + "]";
}
}
