package com.yash.dao;

import java.util.List;

import com.yash.enties.Student;

public interface StudentDao {

public int insert(Student stu);
public int updatedetails(Student stu);
public int deletedetails(int stuid);
public Student selectDetails(int stuid);
public List<Student> listStudents(); 
}
