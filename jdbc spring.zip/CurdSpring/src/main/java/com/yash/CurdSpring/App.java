package com.yash.CurdSpring;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Pattern;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import com.yash.dao.StudentDao;
import com.yash.enties.Student;

/**
 * Hello world!
 *
 */
public class App 
{
    	public static void main( String[] args )
    	{
    	System.out.println( "Hello World!" );
    	Scanner sc=new Scanner(System.in);
    	System.out.println("enter user name");
    	String name =sc.next();
    	System.out.println("enter the password ");
    	String password=sc.next();
    	boolean b=Pattern.matches("[a-zA-Z]{6}", name);
    	boolean c=Pattern.matches("[a-zA-Z0-9]{6}", password);
    	if(b&c)
    	{
    		System.out.println("Log in success full");
    		menu();
    	}
    	else {
    		System.out.println("Invalid data ");
    	}
    	//ApplicationContext context=new ClassPathXmlApplicationContext("appcontext.xml");
    	//StudentDao stdao=context.getBean("StudentDao",StudentDao.class);

    	//Student s=new Student();
    	//s.setId(108);
    	//s.setName("piyush dubey");
    	//int r=stdao.insert(s);//insert 
    	//int r=stdao.updatedetails(s);
    	//System.out.println(r + "Student added Successfully ");
    	//int r=stdao.deletedetails(105);//delete the details
    	//System.out.println(r + "Student deleted Successfully ");
    	//Student s=stdao.selectDetails(108);
    //	System.out.println(s);
    	
    	/*List<Student> students = stdao.listStudents();
        
        for (Student record : students) {
           System.out.print("ID : " + record.getId() );
           System.out.print(", Name : " + record.getName() );
        }*/
    	}

		private static void menu() {
			// TODO Auto-generated method stub
			System.out.println("=========================================");
			System.out.println("1.To Create/ Add Student");
			System.out.println("2.To Update Student ");
			System.out.println("3.To Read a Student");
			System.out.println("4.To Read all the Student");
			System.out.println("5.To Delete a Student");
			System.out.println("6.To exit");
			Scanner sc=new Scanner (System.in);
			System.out.println("=========================================");
			System.out.println();
			System.out.println("Enter ur Choice");
			int n=sc.nextInt();
			ApplicationContext context=new ClassPathXmlApplicationContext("appcontext.xml");
	    	StudentDao stdao=context.getBean("StudentDao",StudentDao.class);

			switch(n)
			{
			case 1:
				System.out.println("enter the Student id To add");
				int id=sc.nextInt();
				System.out.println("enter the Student Name to add");
				String name=sc.next();
				Student s=new Student();
		    	s.setId(id);
		    	s.setName(name);
		    	int r=stdao.insert(s);//insert 
		    	if(r==1)
		    	{
		    		System.out.println("Inserted Successfully");
		    	}
		    	else
		    	{
		    		System.out.println("Error in Insertin");
		    	}
		    	menu();
		    	break;
			case 2:
				System.out.println("enter the Student id To Update ");
				int upid=sc.nextInt();
				System.out.println("enter the Student Name to add");
				String upname=sc.next();
				Student ups=new Student();
		    	ups.setId(upid);
		    	ups.setName(upname);
				int upr=stdao.updatedetails(ups);
				if(upr==1)
		    	{
		    		System.out.println("Updated Successfully");
		    	}
		    	else
		    	{
		    		System.out.println("Error in Update");
		    	}
		    	menu();
		    	break;
			case 3:
				System.out.println("enter the Student id To Update ");
				int selid=sc.nextInt();
				Student s1=stdao.selectDetails(selid);
			    System.out.println(s1);
			    menu();
			    break;
			
			case 4: 
				List<Student> students = stdao.listStudents();
		        
		        for (Student record : students) {
		           System.out.print("ID : " + record.getId() );
		           System.out.print(", Name : " + record.getName() );
		           System.out.println();
		        }
		        
		        menu();
		        break;
			case 5:
				System.out.println("enter the Student id To Update ");
				int delid=sc.nextInt();
				int delr=stdao.deletedetails(delid);//delete the details
				if(delr==0)
				{
					System.out.println( "Student deleted Successfully ");
					
				}
				else
				{
					System.out.println( "Student delete Unsuccessfully ");
					
				}
				menu();
				break;
			case 6:
				System.exit(0);
				default :
					System.out.println("enter correct choice");
					menu();
					break;
					
			}
			
				
			
		}
}
