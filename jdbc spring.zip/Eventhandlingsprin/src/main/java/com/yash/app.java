package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class app {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ApplicationContext context =    new ClassPathXmlApplicationContext("appcontext.xml");
		      ((AbstractApplicationContext) context).start();
			  
		      Student obj = (Student) context.getBean("student");
		     System.out.println(obj.getName());

		  
		      ((AbstractApplicationContext) context).stop();
		      ((AbstractApplicationContext) context).start();
		      ((AbstractApplicationContext) context).close();
	}

}
