package com.yash;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class app {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("appcontext.xml");
		A a= (A)context.getBean("testA");
		a.doTask();
		((AbstractApplicationContext) context).close();
	}
}
