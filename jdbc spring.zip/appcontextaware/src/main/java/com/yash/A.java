package com.yash;

public class A {
	public void doTask(){
		System.out.println("Do some task.");
	}
}
