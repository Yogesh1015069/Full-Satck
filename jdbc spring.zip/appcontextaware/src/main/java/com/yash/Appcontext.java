package com.yash;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

//public class Appcontext implements ApplicationContextAware, BeanNameAware {
//	public class Appcontext implements InitializingBean, DisposableBean {
public class Appcontext{
	
	public ApplicationContext getContext() {
		return context;
	}

	public void setContext(ApplicationContext context) {
		this.context = context;
	}

	ApplicationContext context;

	public void setApplicationContext(ApplicationContext context) throws BeansException {
		// TODO Auto-generated method stub
		this.context = context;

	}

	public void setBeanName(String name) {
		// TODO Auto-generated method stub
		System.out.println("Bean name is: " + name);

	}
	
	
	@PostConstruct
	public void init()  throws Exception {
		System.out.println("Bean is going through init.");
	}

	 @PreDestroy
	public void destroy()  throws Exception {
		System.out.println("Bean will destroy now.");
	}
	
	
/*
	public void afterPropertiesSet() throws Exception {
		System.out.println("Bean is going through afterProperties.");
		
		
	}
	

	public void destroy() throws Exception {
		System.out.println("Bean will destroy now.");
		
	}*/
	
	/* lifecyle usin xml
	public void init() {
		System.out.println("Bean is going through init.");
	}

	public void destroy() {
		System.out.println("Bean will destroy now.");
	}
	
	*/
	 
	
}
