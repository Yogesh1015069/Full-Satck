package com.pack;

import com.pack.Student;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class run {
	public static void main(String[] args) {
		System.out.println("Welcome to first Applications");
		ApplicationContext context = new ClassPathXmlApplicationContext("appcontext.xml");
		Student e = (Student) context.getBean("stud");
		System.out.println(e);
		Student e1 = (Student) context.getBean("stud1");
		System.out.println(e1);
		Student e2 = (Student) context.getBean("stud2");
		System.out.println(e2);
	}
}



