package encapsulation;

class Author
{
	String name;
	String email;
	char gender;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	
	Author(String name,String email,char gender)
	{
		this.name=name;
		this.email=email;
		this.gender=gender;
	}
	 public String toString() {
		return "Author Name: "+name+" email: "+email+" Gender: "+gender;
		 
	 }
	
}

class Book
{
	String name;
	Author author;
	double price;
	int qtyInstock;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getQtyInstock() {
		return qtyInstock;
	}

	public void setQtyInstock(int qtyInstock) {
		this.qtyInstock = qtyInstock;
	}


	Book(String name,Author author,double price,int qtyInstock)
	{
		this.name=name;
		this.author=author;
		this.price=price;
		this.qtyInstock=qtyInstock;
		
	}
	
	public String toString()
	{
		return "Book name -"+name+ "  "+author+" Price: "+price+" QtyInStock :"+qtyInstock;
	}
	
}
public class BookDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Author a =new Author("Yogesh","yosahu22@gmail.com",'M');
		Book  b =new Book("Gain",a,20.0,5);
		System.out.println(b);
	}

}
