package overidding;
class Box{
	int width, height, depth;
	Box(int width, int height,int depth)
	{
		this.depth=depth;
		this.height=height;
		this.width=width;
	}
	 int  volumeOfBox()
	 {
		 return depth*height*width;
	 }
}
public class BoxVolume {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box b=new Box(2,3,4);
		System.out.println(b.volumeOfBox());
	}

}
