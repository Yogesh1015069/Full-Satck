package overidding;

class Fruit
{
	String name;
	String taste;
	String size;
	void eat()
	{
		System.out.println("Name "+name+" Tastes "+taste);
	}
}
class Apple extends Fruit{
	void eat()
	{
		System.out.println("Apple tastes sweet");
	}
}
class Orrange extends Fruit{
	void eat()
	{
		System.out.println("orrange tastes tangy");
	}
}
public class FruitNameTaste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Apple a=new Apple();
		Orrange o=new Orrange();
		a.eat();
		o.eat();
	}

}
