package overidding;

import java.util.Scanner;

class Patient
{
	 String name;
	 double weight;
	 double height;
	 Patient()
	 {
	 Scanner in = new Scanner(System. in);
	 System.out.println("Enter your name: ");
	 name = in. nextLine();
	 System.out.println("Enter your weight: ");
	 weight = in.nextDouble();
	 System.out.println("Enter your height: ");
	 height = in.nextDouble();
	 }
	 void bmi()
	 {
	 double bm;
	 bm=(weight/(height*height))*703;
	 System. out. println("You entered string "+name); 
	 System. out. println("Your weight is " + weight);
	 System. out. println("Your height is " + height);
	 System. out. println("Your bmi is " + bm); 
	 }
}
public class HealthCare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Patient p=new Patient();
		p.bmi();
	}

}
