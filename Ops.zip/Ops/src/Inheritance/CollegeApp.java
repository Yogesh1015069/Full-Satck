package Inheritance;

class Person{
	String name;
	String dob;
	Person(String name,String dob)
	{
		this.name=name;
		this.dob=dob;
	}
	public String toString() {
		return " Name: "+name+" Date of Birth is "+dob;
	}
	
}
class Teacher extends Person{
	double salary;
	String subject;
	Teacher(String n,String year,double salary, String subject)
	{
		super(n,year);
		this.salary=salary;
		this.subject=subject;
	}
	public String toString()
	{
		return "Salary "+salary+"Subject taught "+subject+super.toString();
	}
}
class Student extends Person{
	int studentid;
	Student(String name, String dob,int studentid) {
		super(name, dob);
		this.studentid=studentid;
	}	
	public String toString()
	{
		return "StudentId is "+studentid+super.toString();
	}
}
class CollegeStudent extends Person{
	String collageName;
	int year ;
	CollegeStudent(String name, String dob, String collageName,int year) {
		super(name,dob);
		this.collageName=collageName;
		this.year=year;
		
	}
	
	public String toString()
	{
		return "College name is "+collageName+" Year of study "+year+super.toString();
	}
}
public class CollegeApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p=new Person("yogesh","09/12/2000");
		Student s=new Student("nishant","01/11/2001",1234);
		Teacher t=new Teacher("piyush","13/11/2000",20000.0,"english");
		CollegeStudent c=new CollegeStudent("Sameer","16/07/2000","ITER",4);
		System.out.println(p);
		System.out.println(s);
		System.out.println(t);
		System.out.println(c);

	}

}
