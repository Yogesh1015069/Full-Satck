function onsubmit()
{
    var f=document.getElementById("#fname");
    var l=document.getElementById("#lname");
    var p=document.getElementById("#password");
    var a=document.getElementById("#adhaar");
    var g=document.getElementById("#gender");
    var add=document.getElementById("#adress");
    var e=document.getElementById("#email");
    var m=decodeURIComponent
    document.writeln()
}